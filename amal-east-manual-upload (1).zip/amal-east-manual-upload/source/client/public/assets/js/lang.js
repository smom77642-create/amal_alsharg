/* Arabic/English localization loader, shared by each static HTML page. */
(() => {
  'use strict';

  const STORAGE_KEY = 'amal-east-language';
  const SUPPORTED_LANGUAGES = ['ar', 'en'];
  const FALLBACK_LANGUAGE = 'ar';
  let currentDictionary = {};

  // Reveal content as it enters view. Reduced-motion visitors see everything immediately.
  function initializeScrollReveal() {
    const autoRevealSelectors = [
      'main > .hero > .hero-copy', 'main > .hero > .hero-visual',
      'main > .page-hero > *', 'main .intro-band-inner > *',
      'main .section-heading', 'main .home-project > *', 'main .story-grid > *',
      'main .pillar-card', 'main .value-item', 'main .service-row', 'main .scope-note',
      'main .contact-grid > *', 'main .contact-detail',
      'main .hospital-view', 'main .hospital-service-card', 'main .project-metric',
      'main .goal-card', 'main .chart-card', 'main .floor-row',
      'main .floor-programme-grid > *', 'main .phase-card', 'main .community-visual',
      'main .quote-inner > *', 'main .closing-inner > *', 'main .about-cta-inner > *',
      'main .services-cta-inner > *', 'footer .footer-main > *', 'footer .footer-bottom > *'
    ];
    autoRevealSelectors.forEach((selector) => {
      document.querySelectorAll(selector).forEach((node) => {
        if (!node.closest('[data-reveal]')) node.setAttribute('data-reveal', '');
      });
    });
    document.querySelectorAll('main > section').forEach((section) => {
      if (!section.querySelector('[data-reveal]')) section.setAttribute('data-reveal', '');
    });
    const nodes = [...document.querySelectorAll('[data-reveal]')];
    if (!nodes.length || !('IntersectionObserver' in window) || window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      nodes.forEach((node) => node.classList.add('is-visible'));
      return;
    }
    document.documentElement.classList.add('has-reveal');
    const observer = new IntersectionObserver((entries, currentObserver) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-visible');
        currentObserver.unobserve(entry.target);
      });
    }, { rootMargin: '0px 0px -9% 0px', threshold: 0.08 });
    const serviceCardDelays = new Map(
      [...document.querySelectorAll('.hospital-service-card')].map((card, index) => [card, `${index * 75}ms`])
    );
    nodes.forEach((node, index) => {
      node.style.setProperty('--reveal-delay', serviceCardDelays.get(node) || `${Math.min(index % 4, 3) * 55}ms`);
      observer.observe(node);
    });
  }
  initializeScrollReveal();

  // Mark the footer destination that matches this page for styling and assistive technology.
  function markCurrentFooterLink() {
    const pageFromPath = (path) => {
      const leaf = path.replace(/\/+$/, '').split('/').pop();
      return leaf || 'index.html';
    };
    const currentPage = pageFromPath(window.location.pathname);
    document.querySelectorAll('.footer-links a[href]').forEach((link) => {
      const linkPage = pageFromPath(new URL(link.getAttribute('href'), window.location.href).pathname);
      if (linkPage === currentPage) link.setAttribute('aria-current', 'page');
      else link.removeAttribute('aria-current');
    });
  }
  markCurrentFooterLink();

  // Thin reading-progress indicator for long pages, animated only through transform.
  const progressBar = document.createElement('span');
  progressBar.className = 'scroll-progress';
  progressBar.setAttribute('aria-hidden', 'true');
  document.body.prepend(progressBar);
  let scrollFrame = 0;
  window.addEventListener('scroll', () => {
    if (scrollFrame) return;
    scrollFrame = window.requestAnimationFrame(() => {
      const maxScroll = document.documentElement.scrollHeight - window.innerHeight;
      const ratio = maxScroll > 0 ? window.scrollY / maxScroll : 0;
      progressBar.style.transform = `scaleX(${Math.min(Math.max(ratio, 0), 1)})`;
      scrollFrame = 0;
    });
  }, { passive: true });

  function getSavedLanguage() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return SUPPORTED_LANGUAGES.includes(saved) ? saved : FALLBACK_LANGUAGE;
    } catch (error) {
      console.warn('Language preference could not be read:', error);
      return FALLBACK_LANGUAGE;
    }
  }

  function readPath(dictionary, path) {
    return path.split('.').reduce((value, key) => value && value[key], dictionary);
  }

  function applyTranslations(dictionary, language) {
    currentDictionary = dictionary;
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';

    document.querySelectorAll('[data-i18n]').forEach((element) => {
      const value = readPath(dictionary, element.dataset.i18n);
      if (typeof value === 'string') element.textContent = value;
    });

    // HTML translations are only used for the static, trusted page headings in our JSON files.
    document.querySelectorAll('[data-i18n-html]').forEach((element) => {
      const value = readPath(dictionary, element.dataset.i18nHtml);
      if (typeof value === 'string') element.innerHTML = value;
    });

    document.querySelectorAll('[data-i18n-attr]').forEach((element) => {
      element.dataset.i18nAttr.split(';').forEach((mapping) => {
        const separator = mapping.indexOf(':');
        if (separator < 1) return;
        const attribute = mapping.slice(0, separator).trim();
        const key = mapping.slice(separator + 1).trim();
        const value = readPath(dictionary, key);
        if (attribute && typeof value === 'string') element.setAttribute(attribute, value);
      });
    });

    document.querySelectorAll('[data-language-toggle]').forEach((button) => {
      button.textContent = language === 'ar' ? 'English' : 'العربية';
      button.setAttribute('aria-label', language === 'ar' ? 'Switch language to English' : 'غيّر اللغة إلى العربية');
      button.setAttribute('lang', language === 'ar' ? 'en' : 'ar');
    });

    document.querySelectorAll('.menu-toggle').forEach((button) => {
      button.setAttribute('aria-label', language === 'ar' ? 'فتح القائمة' : 'Open navigation menu');
      const isOpen = button.getAttribute('aria-expanded') === 'true';
      if (isOpen) button.setAttribute('aria-label', language === 'ar' ? 'إغلاق القائمة' : 'Close navigation menu');
    });
  }

  async function loadLanguage(language) {
    const safeLanguage = SUPPORTED_LANGUAGES.includes(language) ? language : FALLBACK_LANGUAGE;
    const response = await fetch(`./locales/${safeLanguage}.json`, { cache: 'no-cache' });
    if (!response.ok) throw new Error(`Could not load ${safeLanguage}.json (${response.status})`);
    const dictionary = await response.json();
    applyTranslations(dictionary, safeLanguage);
    try {
      localStorage.setItem(STORAGE_KEY, safeLanguage);
    } catch (error) {
      console.warn('Language preference could not be saved:', error);
    }
  }

  document.querySelectorAll('[data-language-toggle]').forEach((button) => {
    button.addEventListener('click', async () => {
      const nextLanguage = document.documentElement.lang === 'ar' ? 'en' : 'ar';
      button.disabled = true;
      try {
        await loadLanguage(nextLanguage);
      } catch (error) {
        console.error('Language switch failed:', error);
      } finally {
        button.disabled = false;
      }
    });
  });

  document.querySelectorAll('.menu-toggle').forEach((button) => {
    button.addEventListener('click', () => {
      const nav = document.getElementById(button.getAttribute('aria-controls'));
      const isOpen = button.getAttribute('aria-expanded') === 'true';
      button.setAttribute('aria-expanded', String(!isOpen));
      if (nav) nav.classList.toggle('is-open', !isOpen);
      const language = document.documentElement.lang;
      button.setAttribute('aria-label', !isOpen
        ? (language === 'ar' ? 'إغلاق القائمة' : 'Close navigation menu')
        : (language === 'ar' ? 'فتح القائمة' : 'Open navigation menu'));
    });
  });

  document.querySelectorAll('.site-nav a').forEach((link) => {
    link.addEventListener('click', () => {
      const nav = link.closest('.site-nav');
      if (!nav) return;
      nav.classList.remove('is-open');
      const button = document.querySelector(`.menu-toggle[aria-controls="${nav.id}"]`);
      if (button) button.setAttribute('aria-expanded', 'false');
    });
  });

  document.querySelectorAll('[data-demo-form]').forEach((form) => {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const status = form.querySelector('[data-form-status]');
      if (!form.reportValidity()) {
        if (status) status.textContent = readPath(currentDictionary, 'contact.formInvalid') || '';
        return;
      }
      if (status) status.textContent = readPath(currentDictionary, 'contact.formSuccess') || '';
      form.reset();
    });
  });

  loadLanguage(getSavedLanguage()).catch((error) => {
    console.error('Unable to load the selected language; retaining the Arabic source copy.', error);
    document.documentElement.lang = FALLBACK_LANGUAGE;
    document.documentElement.dir = 'rtl';
  });
})();
