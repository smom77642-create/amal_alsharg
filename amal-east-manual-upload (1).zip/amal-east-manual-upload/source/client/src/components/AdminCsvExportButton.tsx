import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { usePortalLocale } from "@/hooks/usePortalLocale";
import { trpc } from "@/lib/trpc";
import { conversationCsvHeader, conversationCsvRows, type ConversationExportRow } from "@/lib/conversationCsv";
import { Download, LoaderCircle } from "lucide-react";
import { useState } from "react";

const MAX_EXPORT_MESSAGES = 10_000;
const PAGE_SIZE = 250;

type ExportPage = {
  items: ConversationExportRow[];
  hasMore: boolean;
  nextCursor: number | null;
};

export default function AdminCsvExportButton() {
  const { t } = usePortalLocale();
  const utils = trpc.useUtils();
  const [pending, setPending] = useState(false);
  const [notice, setNotice] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [confirmOpen, setConfirmOpen] = useState(false);

  async function downloadCsv() {
    if (fromDate && toDate && fromDate > toDate) {
      setNotice(t.exportCsvInvalidDateRange);
      return;
    }
    setPending(true);
    setNotice("");
    try {
      const rows: ConversationExportRow[] = [];
      let cursor: number | null = null;
      let hasMore = true;
      while (hasMore) {
        const page = await utils.portal.adminExportPage.fetch({
          afterMessageId: cursor,
          fromDate: fromDate || null,
          toDate: toDate || null,
        }) as ExportPage;
        if (rows.length + page.items.length > MAX_EXPORT_MESSAGES) {
          throw new Error("EXPORT_LIMIT");
        }
        rows.push(...page.items);
        if (!page.hasMore) break;
        if (page.nextCursor === null || page.nextCursor === cursor) {
          throw new Error("EXPORT_CURSOR");
        }
        cursor = page.nextCursor;
        hasMore = page.hasMore;
      }

      const csv = `\uFEFF${conversationCsvHeader()}${conversationCsvRows(rows)}`;
      const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      const rangeSuffix = [fromDate && `from-${fromDate}`, toDate && `to-${toDate}`].filter(Boolean).join("_");
      anchor.download = `amal-east-conversations${rangeSuffix ? `-${rangeSuffix}` : `-${new Date().toISOString().slice(0, 10)}`}.csv`;
      document.body.append(anchor);
      anchor.click();
      anchor.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      setNotice(t.exportCsvReady);
    } catch (error) {
      setNotice(error instanceof Error && error.message === "EXPORT_LIMIT" ? t.exportCsvLimit : t.exportCsvError);
    } finally {
      setPending(false);
    }
  }

  return (
    <div className="flex w-full flex-col items-start gap-2">
      <div className="grid w-full max-w-xl grid-cols-2 gap-2">
        <label className="space-y-1 text-xs text-muted-foreground">{t.exportFromDate}<Input type="date" value={fromDate} onChange={event => setFromDate(event.target.value)} aria-label={t.exportFromDate} /></label>
        <label className="space-y-1 text-xs text-muted-foreground">{t.exportToDate}<Input type="date" value={toDate} onChange={event => setToDate(event.target.value)} aria-label={t.exportToDate} /></label>
      </div>
      <AlertDialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <AlertDialogTrigger asChild>
          <Button type="button" variant="outline" disabled={pending}>
            {pending ? <LoaderCircle className="me-2 size-4 animate-spin" /> : <Download className="me-2 size-4" />}
            {pending ? t.exportingCsv : t.exportCsv}
          </Button>
        </AlertDialogTrigger>
        <AlertDialogContent dir={document.documentElement.dir}>
          <AlertDialogHeader>
            <AlertDialogTitle>{t.exportCsvConfirmTitle}</AlertDialogTitle>
            <AlertDialogDescription className="leading-6">{t.exportCsvPrivacy}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t.cancel}</AlertDialogCancel>
            <AlertDialogAction onClick={event => { event.preventDefault(); setConfirmOpen(false); void downloadCsv(); }}>{t.confirmExport}</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      <p className="max-w-xl text-xs leading-5 text-muted-foreground">{t.exportCsvPrivacy}</p>
      {notice && <p role="status" className="text-xs text-muted-foreground">{notice}</p>}
    </div>
  );
}
