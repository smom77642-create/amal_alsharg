import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { getSessionAuthHeaders } from "@/lib/sessionHeaders";
import { LoaderCircle, ZoomIn } from "lucide-react";
import { useEffect, useState } from "react";

type Props = {
  messageId: number;
  fileName: string | null;
  alt: string;
  errorLabel: string;
};

export default function PrivateChatImage({ messageId, fileName, alt, errorLabel }: Props) {
  const [src, setSrc] = useState("");
  const [failed, setFailed] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    let objectUrl = "";
    const abort = new AbortController();
    setSrc("");
    setFailed(false);
    void fetch(`/api/chat/images/${messageId}`, {
      credentials: "include",
      headers: getSessionAuthHeaders(),
      signal: abort.signal,
    }).then(async response => {
      if (!response.ok) throw new Error("Image request failed.");
      const blob = await response.blob();
      if (!blob.type.startsWith("image/")) throw new Error("Invalid image response.");
      objectUrl = URL.createObjectURL(blob);
      setSrc(objectUrl);
    }).catch(error => {
      if (error instanceof Error && error.name === "AbortError") return;
      setFailed(true);
    });
    return () => {
      abort.abort();
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [messageId]);

  if (failed) return <p role="status" className="mt-2 text-xs text-red-700">{errorLabel}</p>;
  if (!src) return <span aria-label={alt} className="mt-2 grid h-32 w-48 place-items-center rounded-xl bg-stone-200 text-stone-600"><LoaderCircle className="size-5 animate-spin" /></span>;

  return (
    <>
      <button type="button" onClick={() => setOpen(true)} className="group relative mt-2 block max-w-full overflow-hidden rounded-xl border border-black/10 bg-stone-100 text-start focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600" aria-label={`${alt}: ${fileName ?? ""}`}>
        <img src={src} alt={alt} loading="lazy" className="max-h-72 max-w-full object-contain transition-transform duration-200 group-hover:scale-[1.02]" />
        <span className="absolute bottom-2 end-2 rounded-full bg-black/70 p-2 text-white opacity-0 transition-opacity group-hover:opacity-100 group-focus-visible:opacity-100"><ZoomIn className="size-4" /></span>
        {fileName && <span className="block max-w-[18rem] truncate px-3 py-2 text-xs text-muted-foreground">{fileName}</span>}
      </button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[92vh] max-w-5xl overflow-auto p-3 sm:p-5">
          <DialogTitle className="sr-only">{alt}</DialogTitle>
          <DialogDescription className="sr-only">{fileName ?? alt}</DialogDescription>
          <img src={src} alt={alt} className="mx-auto max-h-[82vh] max-w-full object-contain" />
          {fileName && <p className="text-center text-sm text-muted-foreground">{fileName}</p>}
        </DialogContent>
      </Dialog>
    </>
  );
}
