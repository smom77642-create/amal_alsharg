import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { useIsMobile } from "@/hooks/useMobile";
import type { PortalCopy, PortalLanguage } from "@/lib/portalI18n";
import { LayoutDashboard, LogOut, MessagesSquare, UserRound } from "lucide-react";
import type { ReactNode } from "react";
import { useState } from "react";

export type PortalUser = {
  name: string | null;
  email: string | null;
  role: "admin" | "user";
};

type DashboardLayoutProps = {
  children: ReactNode;
  user: PortalUser;
  language: PortalLanguage;
  direction: "rtl" | "ltr";
  copy: PortalCopy;
  isAdmin: boolean;
  onToggleLanguage: () => void;
  onSignOut: () => void;
};

export default function DashboardLayout({
  children,
  user,
  language,
  direction,
  copy,
  isAdmin,
  onToggleLanguage,
  onSignOut,
}: DashboardLayoutProps) {
  const [sidebarWidth] = useState(260);
  const isMobile = useIsMobile();
  const currentPath = typeof window === "undefined" ? "" : window.location.pathname;
  const menuItems: Array<{ icon: typeof LayoutDashboard; label: string; href?: string; target?: string }> = isAdmin
    ? [
        { icon: LayoutDashboard, label: copy.inboxTitle, href: "/admin.html" },
        { icon: UserRound, label: copy.usersNav, href: "/admin-users.html" },
      ]
    : [
        { icon: UserRound, label: copy.profileTitle, target: "portal-profile" },
        { icon: MessagesSquare, label: copy.conversationsTitle, target: "portal-conversations" },
      ];

  return (
    <SidebarProvider
      style={{ "--sidebar-width": `${sidebarWidth}px` } as React.CSSProperties}
      dir={direction}
    >
      <Sidebar collapsible="icon">
        <SidebarHeader className="h-16 justify-center px-4">
          <a href="/" className="flex min-w-0 items-center gap-3" aria-label="Amal East">
            <span className="grid size-9 shrink-0 place-items-center rounded-full bg-violet-100 text-violet-800 font-bold">أ</span>
            <span className="truncate text-sm font-semibold">{copy.appTitle}</span>
          </a>
        </SidebarHeader>
        <SidebarContent className="gap-0">
          <SidebarMenu className="px-2 py-1">
            {menuItems.map(item => (
              <SidebarMenuItem key={item.href ?? item.target}>
                {"href" in item && item.href ? (
                  <SidebarMenuButton asChild tooltip={item.label} isActive={currentPath === item.href} className="h-10 font-normal">
                    <a href={item.href}><item.icon className="size-4 text-violet-700" /><span>{item.label}</span></a>
                  </SidebarMenuButton>
                ) : (
                  <SidebarMenuButton
                    tooltip={item.label}
                    className="h-10 font-normal"
                    onClick={() => item.target && document.getElementById(item.target)?.scrollIntoView({ behavior: "smooth", block: "start" })}
                  >
                    <item.icon className="size-4 text-violet-700" />
                    <span>{item.label}</span>
                  </SidebarMenuButton>
                )}
              </SidebarMenuItem>
            ))}
          </SidebarMenu>
        </SidebarContent>
        <SidebarFooter className="gap-2 p-3">
          <button
            type="button"
            onClick={onToggleLanguage}
            className="rounded-lg border border-sidebar-border px-3 py-2 text-sm transition-colors hover:bg-sidebar-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sidebar-ring"
            aria-label={language === "ar" ? "Switch to English" : "التبديل إلى العربية"}
          >
            {copy.switchLanguage}
          </button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="flex w-full items-center gap-3 rounded-lg px-1 py-1 text-start transition-colors hover:bg-sidebar-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sidebar-ring">
                <Avatar className="size-9 shrink-0 border">
                  <AvatarFallback className="text-xs font-medium">
                    {user.name?.trim().charAt(0).toUpperCase() || "A"}
                  </AvatarFallback>
                </Avatar>
                <span className="min-w-0 flex-1 group-data-[collapsible=icon]:hidden">
                  <span className="block truncate text-sm font-medium">{user.name || user.email}</span>
                  <span className="block truncate text-xs text-muted-foreground">{user.email}</span>
                </span>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align={direction === "rtl" ? "start" : "end"} className="w-48">
              <DropdownMenuItem onClick={onSignOut} className="cursor-pointer text-destructive focus:text-destructive">
                <LogOut className="me-2 size-4" />
                <span>{copy.signOut}</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </SidebarFooter>
      </Sidebar>
      <SidebarInset>
        {isMobile && (
          <div className="sticky top-0 z-40 flex h-14 items-center gap-2 border-b bg-background/95 px-3 backdrop-blur">
            <SidebarTrigger className="size-9 rounded-lg" />
            <span className="truncate text-sm font-semibold">{copy.appTitle}</span>
          </div>
        )}
        <main className="min-h-screen flex-1 bg-[#f8f7f5] p-4 text-foreground sm:p-6 lg:p-8" dir={direction}>
          {children}
        </main>
      </SidebarInset>
    </SidebarProvider>
  );
}
