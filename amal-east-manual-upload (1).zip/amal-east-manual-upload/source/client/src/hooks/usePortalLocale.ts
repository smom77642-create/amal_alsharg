import { useCallback, useEffect, useState } from "react";
import { getPortalCopy, getPortalLanguage, PORTAL_LANGUAGE_KEY } from "@/lib/portalI18n";

export function usePortalLocale() {
  const [language, setLanguage] = useState(getPortalLanguage);

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === "ar" ? "rtl" : "ltr";
  }, [language]);

  const toggleLanguage = useCallback(() => {
    setLanguage(current => {
      const next = current === "ar" ? "en" : "ar";
      try {
        localStorage.setItem(PORTAL_LANGUAGE_KEY, next);
      } catch {
        // The preference remains active for this page if storage is unavailable.
      }
      return next;
    });
  }, []);

  return {
    language,
    direction: language === "ar" ? "rtl" : "ltr",
    t: getPortalCopy(language),
    toggleLanguage,
  } as const;
}
