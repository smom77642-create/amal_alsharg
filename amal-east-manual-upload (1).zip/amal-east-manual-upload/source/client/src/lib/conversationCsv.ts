export type ConversationExportRow = {
  userName: string | null;
  userEmail: string | null;
  city: string | null;
  region: string | null;
  country: string | null;
  conversationId: number;
  conversationSubject: string;
  conversationStatus: "open" | "closed";
  conversationCreatedAt: Date | string;
  senderType: "user" | "team";
  messageBody: string;
  attachmentName: string | null;
  attachmentMimeType: string | null;
  messageCreatedAt: Date | string;
};

const CSV_HEADERS = [
  "User name",
  "User email",
  "City",
  "Region / state",
  "Country",
  "Conversation ID",
  "Subject",
  "Status",
  "Conversation created at (UTC)",
  "Sender",
  "Message",
  "Attachment",
  "Attachment type",
  "Message created at (UTC)",
];

function asCsvCell(value: unknown): string {
  let text = value instanceof Date ? value.toISOString() : String(value ?? "");
  // Spreadsheet applications may evaluate cells beginning with formula operators.
  if (/^[\s\u0000]*[=+\-@]/.test(text)) text = `'${text}`;
  return `"${text.replace(/"/g, '""')}"`;
}

export function conversationCsvHeader(): string {
  return `${CSV_HEADERS.map(asCsvCell).join(",")}\r\n`;
}

export function conversationCsvRows(rows: readonly ConversationExportRow[]): string {
  return rows.map(row => [
    row.userName,
    row.userEmail,
    row.city,
    row.region,
    row.country,
    row.conversationId,
    row.conversationSubject,
    row.conversationStatus,
    row.conversationCreatedAt,
    row.senderType,
    row.messageBody,
    row.attachmentName,
    row.attachmentMimeType,
    row.messageCreatedAt,
  ].map(asCsvCell).join(",")).join("\r\n") + (rows.length ? "\r\n" : "");
}
