export const MAX_SOURCE_IMAGE_BYTES = 10 * 1024 * 1024;
export const MAX_PROCESSED_IMAGE_BYTES = 5 * 1024 * 1024;
const ALLOWED_TYPES = new Set(["image/jpeg", "image/png", "image/webp"]);

export type PreparedChatImage = {
  dataUrl: string;
  fileName: string;
  mimeType: string;
  size: number;
};

function toDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => typeof reader.result === "string" ? resolve(reader.result) : reject(new Error("Could not read the processed image."));
    reader.onerror = () => reject(new Error("Could not read the processed image."));
    reader.readAsDataURL(blob);
  });
}

function encodeCanvas(canvas: HTMLCanvasElement): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error("Could not encode the image.")), "image/webp", 0.82);
  });
}

export async function prepareChatImage(file: File): Promise<PreparedChatImage> {
  if (!ALLOWED_TYPES.has(file.type.toLowerCase())) throw new TypeError("UNSUPPORTED_IMAGE_TYPE");
  if (file.size > MAX_SOURCE_IMAGE_BYTES) throw new RangeError("SOURCE_IMAGE_TOO_LARGE");

  const bitmap = await createImageBitmap(file);
  try {
    if (!bitmap.width || !bitmap.height) throw new Error("INVALID_IMAGE_DIMENSIONS");
    let scale = Math.min(1, 1800 / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement("canvas");
    const context = canvas.getContext("2d", { alpha: true });
    if (!context) throw new Error("CANVAS_UNAVAILABLE");

    for (let attempt = 0; attempt < 7; attempt++) {
      canvas.width = Math.max(1, Math.round(bitmap.width * scale));
      canvas.height = Math.max(1, Math.round(bitmap.height * scale));
      context.clearRect(0, 0, canvas.width, canvas.height);
      context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
      const blob = await encodeCanvas(canvas);
      if (!ALLOWED_TYPES.has(blob.type) || blob.size > MAX_PROCESSED_IMAGE_BYTES) {
        scale *= 0.78;
        continue;
      }
      return {
        dataUrl: await toDataUrl(blob),
        fileName: file.name || "image",
        mimeType: blob.type,
        size: blob.size,
      };
    }
    throw new RangeError("PROCESSED_IMAGE_TOO_LARGE");
  } finally {
    bitmap.close();
  }
}
