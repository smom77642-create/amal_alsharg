const supportedImageTypes = ["image/jpeg", "image/png", "image/webp"];

export const MAX_CHAT_IMAGES_PER_BATCH = 8;

export function supportedDroppedImages<T extends { type: string }>(files: ArrayLike<T>): T[] {
  const images: T[] = [];
  for (let index = 0; index < files.length; index += 1) {
    const file = files[index];
    if (file && supportedImageTypes.includes(file.type.toLowerCase())) images.push(file);
  }
  return images;
}

export function firstDroppedImage<T extends { type: string }>(files: ArrayLike<T>): T | null {
  return supportedDroppedImages(files)[0] ?? null;
}
