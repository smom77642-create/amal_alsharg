import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import DashboardLayout from "@/components/DashboardLayout";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import PrivateChatImage from "@/components/PrivateChatImage";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { usePortalLocale } from "@/hooks/usePortalLocale";
import { trpc } from "@/lib/trpc";
import { prepareChatImage, type PreparedChatImage, MAX_SOURCE_IMAGE_BYTES } from "@/lib/prepareChatImage";
import { AlertCircle, ArrowUpRight, ImagePlus, LoaderCircle, LockKeyhole, MessageCircle, SendHorizontal, ShieldCheck, X } from "lucide-react";
import { useEffect, useRef, useState, type DragEvent, type FormEvent } from "react";
import { MAX_CHAT_IMAGES_PER_BATCH, supportedDroppedImages } from "@/lib/chatDropPolicy";

function SignInPanel({ t }: { t: ReturnType<typeof usePortalLocale>["t"] }) {
  return (
    <main className="grid min-h-screen place-items-center bg-[#f8f7f5] p-4">
      <Card className="w-full max-w-xl border-black/10 shadow-sm">
        <CardHeader className="space-y-4">
          <div className="grid size-12 place-items-center rounded-full bg-violet-100 text-violet-800"><LockKeyhole className="size-5" /></div>
          <CardTitle className="text-2xl">{t.signInTitle}</CardTitle>
          <p className="text-sm leading-7 text-muted-foreground">{t.signInBody}</p>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button className="w-full bg-black text-white hover:bg-black/85" onClick={() => startLogin("/portal.html")}>
            {t.signInButton}<ArrowUpRight className="ms-2 size-4" />
          </Button>
          <p className="text-xs leading-6 text-muted-foreground">{t.noLegalId}</p>
        </CardContent>
      </Card>
    </main>
  );
}

export function MessageList({
  conversationId,
  ownerUserId,
  userId,
  isAdmin,
  isClosed,
  direction,
  t,
}: {
  conversationId: number | null;
  ownerUserId: number | null;
  userId: number;
  isAdmin: boolean;
  isClosed: boolean;
  direction: "rtl" | "ltr";
  t: ReturnType<typeof usePortalLocale>["t"];
}) {
  const utils = trpc.useUtils();
  const uploadInput = useRef<HTMLInputElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const dragDepth = useRef(0);
  const lastScrolledMessageId = useRef<number | null>(null);
  const conversationGeneration = useRef(0);
  const messagesQuery = trpc.portal.messages.useQuery(
    { conversationId: conversationId ?? 0 },
    { enabled: conversationId !== null, refetchInterval: 12000 },
  );
  const refreshMessages = async () => {
    await Promise.all([
      utils.portal.messages.invalidate({ conversationId: conversationId ?? 0 }),
      utils.portal.myConversations.invalidate(),
      utils.portal.adminInbox.invalidate(),
    ]);
  };
  const sendMutation = trpc.portal.sendMessage.useMutation({
    onSuccess: refreshMessages,
  });
  const sendImageMutation = trpc.portal.sendImageMessage.useMutation();
  const [reply, setReply] = useState("");
  const [notice, setNotice] = useState("");
  const [selectedImages, setSelectedImages] = useState<PreparedChatImage[]>([]);
  const [preparingImages, setPreparingImages] = useState(false);
  const [sendingImages, setSendingImages] = useState(false);
  const [uploadProgress, setUploadProgress] = useState({ completed: 0, total: 0 });
  const [isDragActive, setIsDragActive] = useState(false);
  const isSending = sendMutation.isPending || sendImageMutation.isPending || preparingImages || sendingImages;

  useEffect(() => {
    conversationGeneration.current += 1;
    setReply("");
    setNotice("");
    setSelectedImages([]);
    setPreparingImages(false);
    setSendingImages(false);
    setUploadProgress({ completed: 0, total: 0 });
    lastScrolledMessageId.current = null;
  }, [conversationId]);

  useEffect(() => {
    if (!messagesQuery.data?.length) return;
    const latestId = messagesQuery.data[messagesQuery.data.length - 1]!.id;
    if (lastScrolledMessageId.current === latestId) return;
    lastScrolledMessageId.current = latestId;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    bottomRef.current?.scrollIntoView({ behavior: reduced ? "auto" : "smooth", block: "end" });
  }, [conversationId, messagesQuery.data]);

  async function handleImageSelection(files?: ArrayLike<File> | null) {
    if (!files?.length || isSending) return;
    const selectionGeneration = conversationGeneration.current;
    setNotice("");
    const incoming = Array.from(files);
    const supported = supportedDroppedImages(incoming);
    const issues: string[] = [];
    if (supported.length < incoming.length) issues.push(t.imageTypeUnsupported);
    const slots = Math.max(0, MAX_CHAT_IMAGES_PER_BATCH - selectedImages.length);
    if (supported.length > slots) issues.push(t.imageBatchLimit);
    if (slots === 0) {
      setNotice(issues.join(" "));
      return;
    }
    const candidates = supported.slice(0, slots);
    try {
      setPreparingImages(true);
      const preparedImages: PreparedChatImage[] = [];
      for (const file of candidates) {
        if (file.size > MAX_SOURCE_IMAGE_BYTES) {
          issues.push(t.imageTooLarge);
          continue;
        }
        try {
          preparedImages.push(await prepareChatImage(file));
        } catch (error) {
          issues.push(error instanceof TypeError ? t.imageTypeUnsupported : t.imagePrepareError);
        }
      }
      if (preparedImages.length && conversationGeneration.current === selectionGeneration) {
        setSelectedImages(current => [...current, ...preparedImages]);
        issues.push(t.imagesSelected);
      }
      if (conversationGeneration.current === selectionGeneration) setNotice(Array.from(new Set(issues)).join(" "));
    } finally {
      if (conversationGeneration.current === selectionGeneration) setPreparingImages(false);
    }
  }

  function containsFiles(event: DragEvent<HTMLElement>) {
    return Array.from(event.dataTransfer.types).includes("Files");
  }

  function handleDragEnter(event: DragEvent<HTMLElement>) {
    if (isSending || !containsFiles(event)) return;
    event.preventDefault();
    dragDepth.current += 1;
    setIsDragActive(true);
  }

  function handleDragOver(event: DragEvent<HTMLElement>) {
    if (isSending || !containsFiles(event)) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = "copy";
  }

  function handleDragLeave(event: DragEvent<HTMLElement>) {
    if (!containsFiles(event)) return;
    event.preventDefault();
    dragDepth.current = Math.max(0, dragDepth.current - 1);
    if (dragDepth.current === 0) setIsDragActive(false);
  }

  function handleDrop(event: DragEvent<HTMLElement>) {
    if (!containsFiles(event)) return;
    event.preventDefault();
    dragDepth.current = 0;
    setIsDragActive(false);
    if (isSending) return;
    const images = supportedDroppedImages(event.dataTransfer.files);
    if (images.length) void handleImageSelection(images);
    else setNotice(t.imageTypeUnsupported);
  }

  function handleReply(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!conversationId || isSending || (!reply.trim() && !selectedImages.length)) return;
    if (selectedImages.length) {
      const batch = [...selectedImages];
      const messageBody = reply.trim();
      const batchGeneration = conversationGeneration.current;
      setSendingImages(true);
      setUploadProgress({ completed: 0, total: batch.length });
      setNotice("");
      void (async () => {
        let sent = 0;
        try {
          for (const image of batch) {
            await sendImageMutation.mutateAsync({
              conversationId,
              body: sent === 0 ? messageBody : "",
              imageDataUrl: image.dataUrl,
              fileName: image.fileName,
            });
            sent += 1;
            if (conversationGeneration.current !== batchGeneration) break;
            setSelectedImages(batch.slice(sent));
            setUploadProgress({ completed: sent, total: batch.length });
            if (sent === 1 && messageBody) setReply("");
          }
          if (conversationGeneration.current === batchGeneration && sent === batch.length) setNotice(t.imagesSent);
        } catch {
          if (conversationGeneration.current === batchGeneration) setNotice(sent ? t.imageBatchPartialError : t.imageSendError);
        } finally {
          if (sent) {
            try { await refreshMessages(); } catch { /* Polling will refresh the thread if invalidation fails. */ }
          }
          if (conversationGeneration.current === batchGeneration) setSendingImages(false);
        }
      })();
    } else {
      sendMutation.mutate(
        { conversationId, body: reply.trim() },
        { onSuccess: () => { setReply(""); setNotice(""); }, onError: () => setNotice(t.error) },
      );
    }
  }

  if (!conversationId) {
    return <div className="grid min-h-56 place-items-center rounded-2xl border border-dashed bg-white p-6 text-center text-sm text-muted-foreground">{t.selectConversation}</div>;
  }

  return (
    <section
      aria-label={t.thread}
      data-drag-active={isDragActive}
      onDragEnter={handleDragEnter}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className={`relative flex min-h-[420px] min-w-0 flex-col overflow-hidden rounded-2xl border bg-white shadow-sm transition-colors duration-150 ${isDragActive ? "border-violet-500 ring-2 ring-violet-300" : "border-black/10"}`}
    >
      {isDragActive && <div className="pointer-events-none absolute inset-2 z-20 grid place-items-center rounded-xl border-2 border-dashed border-violet-500 bg-violet-50/95 text-center text-sm font-semibold text-violet-950" role="status">{t.dropImageHere}</div>}
      <div className="flex items-center gap-2 border-b px-5 py-4 text-sm font-semibold"><MessageCircle className="size-4 text-violet-700" />{t.thread}</div>
      <div className="max-h-[58vh] min-h-56 flex-1 space-y-3 overflow-y-auto overscroll-contain p-4 sm:p-5" aria-live="polite">
        {messagesQuery.isLoading && <p className="text-sm text-muted-foreground">{t.loading}</p>}
        {messagesQuery.error && <p role="alert" className="text-sm text-red-700">{t.error}</p>}
        {!messagesQuery.isLoading && !messagesQuery.error && messagesQuery.data?.length === 0 && <p className="text-sm text-muted-foreground">{t.noMessages}</p>}
        {messagesQuery.data?.map(message => {
          const mine = message.senderUserId === userId;
          const fromSupport = isAdmin ? message.senderUserId === ownerUserId : !mine;
          return (
            <article key={message.id} className={`max-w-[88%] rounded-2xl px-4 py-3 ${mine ? "ms-auto bg-violet-100 text-violet-950" : "me-auto bg-stone-100 text-stone-900"}`}>
              <p className="mb-1 text-xs font-semibold text-muted-foreground">{mine ? t.you : fromSupport ? t.support : t.customer}</p>
              {message.body && <p className="whitespace-pre-wrap break-words text-sm leading-6">{message.body}</p>}
              {message.attachmentUrl && <PrivateChatImage messageId={message.id} fileName={message.attachmentName} alt={t.imageAlt} errorLabel={t.imageLoadError} />}
              <time className="mt-2 block text-[11px] text-muted-foreground" dateTime={new Date(message.createdAt).toISOString()}>{new Date(message.createdAt).toLocaleString(direction === "rtl" ? "ar" : "en")}</time>
            </article>
          );
        })}
        <div ref={bottomRef} />
      </div>
      {ownerUserId !== null && isClosed && !isAdmin && <p className="border-t bg-stone-50 px-4 py-3 text-sm text-muted-foreground">{t.closedNotice}</p>}
      {ownerUserId !== null && (!isClosed || isAdmin) && (
        <form onSubmit={handleReply} className="space-y-3 border-t p-3 sm:p-4">
          {selectedImages.length > 0 && <div role="group" className="grid grid-cols-2 gap-2 sm:grid-cols-4" aria-label={t.selectedImages}>
            {selectedImages.map((image, index) => <div key={`${image.fileName}-${index}`} className="relative min-w-0 overflow-hidden rounded-xl border bg-stone-50 p-2">
              <img src={image.dataUrl} alt={t.imageSelected} className="aspect-square w-full rounded-lg object-cover" />
              <span className="mt-1 block truncate text-xs text-muted-foreground">{image.fileName}</span>
              {!sendingImages && <Button type="button" variant="ghost" size="icon" aria-label={`${t.removeImage} ${index + 1}`} className="absolute end-3 top-3 size-8 rounded-full bg-white/90 shadow-sm" onClick={() => { setSelectedImages(current => current.filter((_, itemIndex) => itemIndex !== index)); setNotice(""); }}><X className="size-4" /></Button>}
            </div>)}
          </div>}
          <Textarea
            value={reply}
            onChange={event => setReply(event.target.value)}
            rows={2}
            maxLength={5000}
            placeholder={t.replyPlaceholder}
            aria-label={t.replyPlaceholder}
            className="min-h-11 resize-y bg-stone-50"
          />
          <input ref={uploadInput} type="file" accept="image/jpeg,image/png,image/webp" multiple className="sr-only" onChange={event => { void handleImageSelection(event.target.files); event.currentTarget.value = ""; }} />
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex min-w-0 flex-1 flex-wrap items-center gap-2">
              <Button type="button" variant="outline" size="sm" disabled={isSending} onClick={() => uploadInput.current?.click()}><ImagePlus className="size-4" />{t.addImage}</Button>
              <span className="text-[11px] leading-5 text-muted-foreground">{t.imageMaxSize}. {t.imageBatchHint}. {t.dragDropHint}</span>
            </div>
            <Button type="submit" disabled={(!reply.trim() && !selectedImages.length) || isSending} className="shrink-0 bg-black text-white hover:bg-black/85">
              {isSending ? <LoaderCircle className="size-4 animate-spin" /> : <SendHorizontal className="size-4" />}{sendingImages ? `${t.imagesUploading} ${Math.min(uploadProgress.completed + 1, uploadProgress.total)}/${uploadProgress.total}` : isSending && sendImageMutation.isPending ? t.imageUploading : t.send}
            </Button>
          </div>
          <p className="text-[11px] leading-5 text-muted-foreground">{t.imagePrivacy}</p>
          {notice && <p role="status" className="text-xs text-muted-foreground">{notice}</p>}
        </form>
      )}
    </section>
  );
}

export default function Portal() {
  const { user, loading, logout } = useAuth();
  const { language, direction, t, toggleLanguage } = usePortalLocale();
  const utils = trpc.useUtils();
  const profileQuery = trpc.portal.profile.useQuery(undefined, { enabled: Boolean(user && user.loginMethod?.toLowerCase() === "google") });
  const conversationsQuery = trpc.portal.myConversations.useQuery(undefined, {
    enabled: Boolean(user && user.loginMethod?.toLowerCase() === "google"),
    refetchInterval: 20000,
  });
  const saveProfile = trpc.portal.saveProfile.useMutation({
    onSuccess: async () => {
      setProfileNotice(t.profileSaved);
      await utils.portal.profile.invalidate();
    },
    onError: () => setProfileNotice(t.profileError),
  });
  const startConversation = trpc.portal.startConversation.useMutation({
    onSuccess: async id => {
      setActiveConversationId(id);
      setFirstMessage("");
      setProfileNotice("");
      await Promise.all([utils.portal.myConversations.invalidate(), utils.portal.adminInbox.invalidate()]);
    },
    onError: () => setProfileNotice(t.error),
  });
  const [profile, setProfile] = useState({ country: "", region: "", city: "" });
  const [consent, setConsent] = useState(false);
  const [subject, setSubject] = useState("question");
  const [firstMessage, setFirstMessage] = useState("");
  const [activeConversationId, setActiveConversationId] = useState<number | null>(null);
  const [profileNotice, setProfileNotice] = useState("");

  useEffect(() => {
    if (!profileQuery.data) return;
    setProfile({ country: profileQuery.data.country, region: profileQuery.data.region, city: profileQuery.data.city });
  }, [profileQuery.data]);

  useEffect(() => {
    if (activeConversationId !== null || !conversationsQuery.data?.length) return;
    setActiveConversationId(conversationsQuery.data[0]!.id);
  }, [activeConversationId, conversationsQuery.data]);

  function submitProfile(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setProfileNotice("");
    saveProfile.mutate({ ...profile, consent: true });
  }

  function submitFirstMessage(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!profileQuery.data || !firstMessage.trim()) return;
    startConversation.mutate({ subject, message: firstMessage.trim() });
  }

  if (loading) return <div className="grid min-h-screen place-items-center text-muted-foreground"><LoaderCircle className="size-6 animate-spin" /></div>;
  if (!user) return <SignInPanel t={t} />;
  if ((user.loginMethod ?? "").trim().toLowerCase() !== "google") {
    return <main className="grid min-h-screen place-items-center bg-[#f8f7f5] p-4"><Card className="w-[calc(100vw-2rem)] min-w-0 max-w-lg overflow-hidden"><CardHeader><CardTitle>{t.accountRequired}</CardTitle><p className="text-sm text-muted-foreground">{t.accessDenied}</p></CardHeader><CardContent className="flex gap-3"><Button onClick={() => void logout()} variant="outline">{t.signOut}</Button><Button onClick={() => startLogin("/portal.html")} className="bg-black text-white">{t.signInButton}</Button></CardContent></Card></main>;
  }

  const isAdmin = user.role === "admin";
  return (
    <DashboardLayout
      user={user}
      language={language}
      direction={direction}
      copy={t}
      isAdmin={isAdmin}
      onToggleLanguage={toggleLanguage}
      onSignOut={() => void logout()}
    >
      <div className="mx-auto max-w-6xl space-y-6" dir={direction}>
        <header className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="mb-2 text-xs font-semibold uppercase tracking-[0.18em] text-violet-800">{t.verifiedLabel}</p>
            <h1 className="text-3xl font-semibold tracking-tight text-stone-950">{t.newMessageTitle}</h1>
            <p className="mt-2 max-w-2xl text-sm leading-7 text-muted-foreground">{t.newMessageIntro}</p>
          </div>
          {isAdmin && <a className="inline-flex items-center gap-2 rounded-xl border bg-white px-4 py-2 text-sm font-medium hover:border-violet-400" href="/admin.html">{t.inbox}<ArrowUpRight className="size-4" /></a>}
        </header>

        <Alert className="border-violet-200 bg-violet-50/70">
          <ShieldCheck className="size-4 text-violet-800" />
          <AlertTitle>{t.privacyTitle}</AlertTitle>
          <AlertDescription className="leading-6">{t.privacyBody}</AlertDescription>
        </Alert>

        <div className="grid gap-6 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]">
          <div id="portal-profile" className="space-y-6">
            <Card className="border-black/10 shadow-sm">
              <CardHeader><CardTitle>{t.profileTitle}</CardTitle><p className="text-sm leading-6 text-muted-foreground">{t.profileIntro}</p></CardHeader>
              <CardContent>
                <form onSubmit={submitProfile} className="space-y-4">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <label className="space-y-2 text-sm font-medium sm:col-span-2">{t.country}<Input value={profile.country} onChange={event => setProfile(value => ({ ...value, country: event.target.value }))} required maxLength={120} autoComplete="country-name" /></label>
                    <label className="space-y-2 text-sm font-medium">{t.region}<Input value={profile.region} onChange={event => setProfile(value => ({ ...value, region: event.target.value }))} required maxLength={120} autoComplete="address-level1" /></label>
                    <label className="space-y-2 text-sm font-medium">{t.city}<Input value={profile.city} onChange={event => setProfile(value => ({ ...value, city: event.target.value }))} required maxLength={120} autoComplete="address-level2" /></label>
                  </div>
                  <label className="flex items-start gap-3 rounded-xl bg-stone-50 p-3 text-sm leading-6">
                    <input type="checkbox" checked={consent} onChange={event => setConsent(event.target.checked)} required className="mt-1 size-4 accent-violet-700" />
                    <span>{t.consent}</span>
                  </label>
                  <Button type="submit" disabled={!consent || saveProfile.isPending} className="bg-black text-white hover:bg-black/85">
                    {saveProfile.isPending && <LoaderCircle className="me-2 size-4 animate-spin" />}{saveProfile.isPending ? t.saving : t.saveProfile}
                  </Button>
                  <p className="text-xs leading-5 text-muted-foreground">{t.noAddress}</p>
                  {profileNotice && <p role="status" className="text-sm text-violet-800">{profileNotice}</p>}
                </form>
              </CardContent>
            </Card>

            <Card className="border-black/10 shadow-sm">
              <CardHeader><CardTitle>{t.newMessageTitle}</CardTitle><p className="text-sm leading-6 text-muted-foreground">{t.completeProfile}</p></CardHeader>
              <CardContent>
                <form onSubmit={submitFirstMessage} className="space-y-4">
                  <label className="block space-y-2 text-sm font-medium">{t.subject}
                    <select value={subject} onChange={event => setSubject(event.target.value)} className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm">
                      <option value="question">{t.subjectGeneral}</option><option value="partnership">{t.subjectPartnership}</option><option value="other">{t.subjectOther}</option>
                    </select>
                  </label>
                  <label className="block space-y-2 text-sm font-medium">{t.firstMessage}<Textarea value={firstMessage} onChange={event => setFirstMessage(event.target.value)} placeholder={t.messagePlaceholder} rows={5} maxLength={5000} required className="resize-y bg-stone-50" /></label>
                  <Button type="submit" disabled={!profileQuery.data || !firstMessage.trim() || startConversation.isPending} className="bg-black text-white hover:bg-black/85">
                    {startConversation.isPending && <LoaderCircle className="me-2 size-4 animate-spin" />}{t.startConversation}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          <section id="portal-conversations" className="space-y-4">
            <h2 className="text-xl font-semibold">{t.conversationsTitle}</h2>
            {conversationsQuery.isLoading && <p className="text-sm text-muted-foreground">{t.loading}</p>}
            {conversationsQuery.error && <p role="alert" className="text-sm text-red-700">{t.error}</p>}
            {!conversationsQuery.isLoading && !conversationsQuery.error && conversationsQuery.data?.length === 0 && <div className="rounded-2xl border border-dashed bg-white p-6 text-sm text-muted-foreground">{t.noConversations}</div>}
            <div className="space-y-2">
              {conversationsQuery.data?.map(conversation => (
                <button key={conversation.id} type="button" onClick={() => setActiveConversationId(conversation.id)} className={`w-full rounded-xl border p-4 text-start transition-colors ${activeConversationId === conversation.id ? "border-violet-400 bg-violet-50" : "border-black/10 bg-white hover:border-violet-300"}`}>
                  <span className="flex items-center justify-between gap-3"><strong className="truncate text-sm">{conversation.subject}</strong><span className="shrink-0 text-xs text-muted-foreground">{conversation.status === "open" ? t.open : t.closed}</span></span>
                  <time className="mt-2 block text-xs text-muted-foreground">{new Date(conversation.updatedAt).toLocaleString(language === "ar" ? "ar" : "en")}</time>
                </button>
              ))}
            </div>
            {conversationsQuery.data?.length ? (
              <MessageList
                conversationId={activeConversationId}
                ownerUserId={user.id}
                userId={user.id}
                isAdmin={isAdmin}
                isClosed={conversationsQuery.data?.find(conversation => conversation.id === activeConversationId)?.status === "closed"}
                direction={direction}
                t={t}
              />
            ) : null}
          </section>
        </div>
        <footer className="border-t border-black/10 pt-4 text-xs leading-6 text-muted-foreground">{t.noLegalId}</footer>
      </div>
    </DashboardLayout>
  );
}
