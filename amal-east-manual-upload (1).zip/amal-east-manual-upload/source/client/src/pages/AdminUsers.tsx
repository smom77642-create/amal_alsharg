import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import AdminCsvExportButton from "@/components/AdminCsvExportButton";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { usePortalLocale } from "@/hooks/usePortalLocale";
import { trpc } from "@/lib/trpc";
import { ArrowUpRight, LoaderCircle, Search, UsersRound } from "lucide-react";
import { useEffect, useState } from "react";

const PAGE_SIZE = 25;

function formatDate(value: Date | string | null, locale: string) {
  if (!value) return "—";
  const date = value instanceof Date ? value : new Date(value);
  return Number.isNaN(date.getTime()) ? "—" : date.toLocaleString(locale);
}

export default function AdminUsers() {
  const { user, loading, logout } = useAuth();
  const { language, direction, t, toggleLanguage } = usePortalLocale();
  const [page, setPage] = useState(0);
  const [search, setSearch] = useState("");
  const [query, setQuery] = useState("");

  useEffect(() => {
    const timer = window.setTimeout(() => {
      setPage(0);
      setQuery(search.trim());
    }, 250);
    return () => window.clearTimeout(timer);
  }, [search]);

  const usersQuery = trpc.portal.adminUsers.useQuery(
    { page, pageSize: PAGE_SIZE, query },
    { enabled: Boolean(user?.role === "admin" && user.loginMethod?.trim().toLowerCase() === "google"), placeholderData: previous => previous },
  );

  if (loading) return <div className="grid min-h-screen place-items-center text-muted-foreground"><LoaderCircle className="size-6 animate-spin" /></div>;
  if (!user) {
    return <main className="grid min-h-screen min-w-0 place-items-center overflow-x-hidden bg-[#f8f7f5] p-4" style={{ width: "100vw", boxSizing: "border-box" }}><Card className="min-w-0 max-w-lg overflow-hidden" style={{ width: "min(32rem, calc(100vw - 2rem))", boxSizing: "border-box" }}><CardHeader><CardTitle>{t.signInTitle}</CardTitle><p className="text-sm leading-6 text-muted-foreground">{t.inboxIntro}</p></CardHeader><CardContent><Button onClick={() => startLogin("/admin-users.html")} className="w-full bg-black text-white">{t.signInButton}<ArrowUpRight className="ms-2 size-4" /></Button></CardContent></Card></main>;
  }
  if (user.role !== "admin" || user.loginMethod?.trim().toLowerCase() !== "google") {
    return <main className="grid min-h-screen min-w-0 place-items-center overflow-x-hidden bg-[#f8f7f5] p-4" style={{ width: "100vw", boxSizing: "border-box" }}><Card className="min-w-0 max-w-lg overflow-hidden" style={{ width: "min(32rem, calc(100vw - 2rem))", boxSizing: "border-box" }}><CardHeader><CardTitle>{t.accessDenied}</CardTitle></CardHeader><CardContent className="flex flex-wrap gap-3"><Button variant="outline" onClick={() => void logout()}>{t.signOut}</Button><a href="/portal.html" className="inline-flex items-center gap-2 rounded-md bg-black px-4 py-2 text-sm font-medium text-white">{t.profile}<ArrowUpRight className="size-4" /></a></CardContent></Card></main>;
  }

  const result = usersQuery.data;
  const totalPages = Math.max(1, Math.ceil((result?.total ?? 0) / PAGE_SIZE));
  const locale = language === "ar" ? "ar" : "en";

  return (
    <DashboardLayout
      user={user}
      language={language}
      direction={direction}
      copy={t}
      isAdmin
      onToggleLanguage={toggleLanguage}
      onSignOut={() => void logout()}
    >
      <div className="mx-auto max-w-7xl space-y-6" dir={direction}>
        <header className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.18em] text-violet-800"><UsersRound className="size-4" />{t.usersNav}</p>
            <h1 className="text-3xl font-semibold tracking-tight text-stone-950">{t.usersTitle}</h1>
            <p className="mt-2 max-w-3xl text-sm leading-7 text-muted-foreground">{t.usersIntro}</p>
          </div>
          <a href="/admin.html" className="inline-flex items-center gap-2 rounded-xl border bg-white px-4 py-2 text-sm font-medium hover:border-violet-400">{t.inbox}<ArrowUpRight className="size-4" /></a>
        </header>

        <Card className="border-black/10 shadow-sm">
          <CardHeader className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div><CardTitle>{t.usersTitle}</CardTitle><p className="mt-1 text-sm text-muted-foreground">{result?.total ?? 0} · {t.customer}</p></div>
            <AdminCsvExportButton />
          </CardHeader>
          <CardContent className="space-y-5">
            <label className="relative block max-w-lg">
              <Search className="pointer-events-none absolute start-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
              <Input value={search} onChange={event => setSearch(event.target.value)} placeholder={t.searchUsers} aria-label={t.searchUsers} className="ps-9" />
            </label>

            {usersQuery.isLoading && <div className="flex items-center gap-2 text-sm text-muted-foreground"><LoaderCircle className="size-4 animate-spin" />{t.loading}</div>}
            {usersQuery.error && <p role="alert" className="text-sm text-red-700">{t.error}</p>}
            {!usersQuery.isLoading && !usersQuery.error && result?.items.length === 0 && <div className="rounded-xl border border-dashed p-8 text-center text-sm text-muted-foreground">{t.noUsers}</div>}

            <div className="grid gap-3">
              {result?.items.map(account => {
                const location = [account.city, account.region, account.country].filter(Boolean).join(", ");
                return (
                  <article key={account.id} className="grid gap-4 rounded-xl border border-black/10 bg-white p-4 sm:grid-cols-2 xl:grid-cols-3">
                    <div className="min-w-0"><p className="text-xs text-muted-foreground">{t.userName}</p><p className="mt-1 truncate font-semibold">{account.name || "—"}</p><p className="truncate text-sm text-muted-foreground">{account.email || "—"}</p></div>
                    <div className="min-w-0"><p className="text-xs text-muted-foreground">{t.location}</p><p className="mt-1 break-words text-sm">{location || t.locationNotProvided}</p></div>
                    <div><p className="text-xs text-muted-foreground">{t.accountRole}</p><p className="mt-1 text-sm">{account.role === "admin" ? t.adminRole : t.memberRole}</p><p className="mt-2 text-xs text-muted-foreground">{t.loginMethod}: {account.loginMethod || "—"}</p></div>
                    <div><p className="text-xs text-muted-foreground">{t.registeredAt}</p><time className="mt-1 block text-sm" dateTime={new Date(account.createdAt).toISOString()}>{formatDate(account.createdAt, locale)}</time></div>
                    <div><p className="text-xs text-muted-foreground">{t.lastSignedIn}</p><time className="mt-1 block text-sm" dateTime={new Date(account.lastSignedIn).toISOString()}>{formatDate(account.lastSignedIn, locale)}</time></div>
                    <div><p className="text-xs text-muted-foreground">{t.consentRecordedAt}</p><time className="mt-1 block text-sm" dateTime={account.consentAt ? new Date(account.consentAt).toISOString() : undefined}>{formatDate(account.consentAt, locale)}</time></div>
                  </article>
                );
              })}
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 border-t pt-4">
              <p className="text-sm text-muted-foreground">{t.showing} {result?.total ? page * PAGE_SIZE + 1 : 0}–{Math.min((page + 1) * PAGE_SIZE, result?.total ?? 0)} {t.of} {result?.total ?? 0}</p>
              <div className="flex gap-2">
                <Button variant="outline" disabled={page === 0 || usersQuery.isFetching} onClick={() => setPage(value => Math.max(0, value - 1))}>{t.previousPage}</Button>
                <Button variant="outline" disabled={page + 1 >= totalPages || usersQuery.isFetching} onClick={() => setPage(value => value + 1)}>{t.nextPage}</Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
