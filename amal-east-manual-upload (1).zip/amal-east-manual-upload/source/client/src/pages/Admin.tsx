import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import DashboardLayout from "@/components/DashboardLayout";
import AdminCsvExportButton from "@/components/AdminCsvExportButton";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { usePortalLocale } from "@/hooks/usePortalLocale";
import { trpc } from "@/lib/trpc";
import { ArrowUpRight, LoaderCircle, LockKeyhole, MapPin } from "lucide-react";
import { useEffect, useState } from "react";
import { MessageList } from "./Portal";

export default function Admin() {
  const { user, loading, logout } = useAuth();
  const { language, direction, t, toggleLanguage } = usePortalLocale();
  const utils = trpc.useUtils();
  const inboxQuery = trpc.portal.adminInbox.useQuery(undefined, {
    enabled: Boolean(user?.role === "admin" && user.loginMethod?.toLowerCase() === "google"),
    refetchInterval: 15000,
  });
  const updateStatus = trpc.portal.setStatus.useMutation({
    onSuccess: async () => {
      await Promise.all([utils.portal.adminInbox.invalidate(), utils.portal.messages.invalidate()]);
    },
  });
  const [selectedId, setSelectedId] = useState<number | null>(null);

  useEffect(() => {
    if (selectedId !== null || !inboxQuery.data?.length) return;
    setSelectedId(inboxQuery.data[0]!.id);
  }, [selectedId, inboxQuery.data]);

  if (loading) return <div className="grid min-h-screen place-items-center text-muted-foreground"><LoaderCircle className="size-6 animate-spin" /></div>;
  if (!user) {
    return <main className="grid min-h-screen min-w-0 place-items-center overflow-x-hidden bg-[#f8f7f5] p-4" style={{ width: "100vw", boxSizing: "border-box" }}><Card className="min-w-0 max-w-lg overflow-hidden" style={{ width: "min(32rem, calc(100vw - 2rem))", boxSizing: "border-box" }}><CardHeader><div className="grid size-11 place-items-center rounded-full bg-violet-100 text-violet-800"><LockKeyhole className="size-5" /></div><CardTitle>{t.signInTitle}</CardTitle><p className="text-sm leading-6 text-muted-foreground">{t.inboxIntro}</p></CardHeader><CardContent><Button onClick={() => startLogin("/admin.html")} className="w-full bg-black text-white">{t.signInButton}<ArrowUpRight className="ms-2 size-4" /></Button></CardContent></Card></main>;
  }
  if (user.role !== "admin" || user.loginMethod?.toLowerCase() !== "google") {
    return <main className="grid min-h-screen min-w-0 place-items-center overflow-x-hidden bg-[#f8f7f5] p-4" style={{ width: "100vw", boxSizing: "border-box" }}><Card className="min-w-0 max-w-lg overflow-hidden" style={{ width: "min(32rem, calc(100vw - 2rem))", boxSizing: "border-box" }}><CardHeader><CardTitle>{t.accessDenied}</CardTitle></CardHeader><CardContent className="flex flex-wrap gap-3"><Button variant="outline" onClick={() => void logout()}>{t.signOut}</Button><a href="/portal.html" className="inline-flex items-center gap-2 rounded-md bg-black px-4 py-2 text-sm font-medium text-white">{t.profile}<ArrowUpRight className="size-4" /></a></CardContent></Card></main>;
  }

  const selected = inboxQuery.data?.find(thread => thread.id === selectedId) ?? null;
  const locationLabel = selected ? [selected.city, selected.region, selected.country].filter(Boolean).join(", ") : "";

  return (
    <DashboardLayout
      user={user}
      language={language}
      direction={direction}
      copy={t}
      isAdmin
      onToggleLanguage={toggleLanguage}
      onSignOut={() => void logout()}
    >
      <div className="mx-auto max-w-7xl space-y-6" dir={direction}>
        <header className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="mb-2 text-xs font-semibold uppercase tracking-[0.18em] text-violet-800">{t.verifiedLabel}</p>
            <h1 className="text-3xl font-semibold tracking-tight text-stone-950">{t.inboxTitle}</h1>
            <p className="mt-2 max-w-2xl text-sm leading-7 text-muted-foreground">{t.inboxIntro}</p>
          </div>
          <div className="flex flex-wrap items-start gap-3">
            <AdminCsvExportButton />
            <a href="/portal.html" className="inline-flex items-center gap-2 rounded-xl border bg-white px-4 py-2 text-sm font-medium hover:border-violet-400">{t.profile}<ArrowUpRight className="size-4" /></a>
          </div>
        </header>

        <Alert className="border-violet-200 bg-violet-50/70">
          <LockKeyhole className="size-4 text-violet-800" />
          <AlertTitle>{t.privacyTitle}</AlertTitle>
          <AlertDescription className="leading-6">{t.privacyBody}</AlertDescription>
        </Alert>

        <div className="grid min-h-[620px] gap-5 xl:grid-cols-[minmax(280px,0.8fr)_minmax(0,1.2fr)]">
          <section id="portal-inbox" className="space-y-3">
            <div className="flex items-center justify-between"><h2 className="text-lg font-semibold">{t.inboxTitle}</h2><span className="rounded-full bg-violet-100 px-2.5 py-1 text-xs font-semibold text-violet-900">{inboxQuery.data?.length ?? 0}</span></div>
            {inboxQuery.isLoading && <p className="text-sm text-muted-foreground">{t.loading}</p>}
            {inboxQuery.error && <p role="alert" className="text-sm text-red-700">{t.error}</p>}
            {!inboxQuery.isLoading && !inboxQuery.error && inboxQuery.data?.length === 0 && <div className="rounded-2xl border border-dashed bg-white p-6 text-sm text-muted-foreground">{t.noInbox}</div>}
            <div className="space-y-2">
              {inboxQuery.data?.map(thread => {
                const location = [thread.city, thread.region, thread.country].filter(Boolean).join(", ");
                return (
                  <button key={thread.id} type="button" onClick={() => setSelectedId(thread.id)} className={`w-full rounded-2xl border p-4 text-start transition-colors ${selectedId === thread.id ? "border-violet-400 bg-violet-50" : "border-black/10 bg-white hover:border-violet-300"}`}>
                    <span className="flex items-start justify-between gap-3"><strong className="min-w-0 truncate text-sm">{thread.subject}</strong><span className="shrink-0 rounded-full bg-stone-100 px-2 py-0.5 text-[11px]">{thread.status === "open" ? t.open : t.closed}</span></span>
                    <span className="mt-2 block truncate text-sm font-medium">{thread.userName || thread.userEmail || t.customer}</span>
                    <span className="mt-1 block truncate text-xs text-muted-foreground">{thread.userEmail}</span>
                    {location && <span className="mt-2 flex items-center gap-1 text-xs text-muted-foreground"><MapPin className="size-3 shrink-0" />{location}</span>}
                    <time className="mt-2 block text-xs text-muted-foreground">{new Date(thread.updatedAt).toLocaleString(language === "ar" ? "ar" : "en")}</time>
                  </button>
                );
              })}
            </div>
          </section>

          <section id="portal-thread" className="space-y-3">
            {selected ? (
              <Card className="border-black/10 shadow-sm">
                <CardHeader className="flex flex-row flex-wrap items-start justify-between gap-3 space-y-0">
                  <div className="min-w-0"><CardTitle className="truncate text-lg">{selected.subject}</CardTitle><p className="mt-1 truncate text-sm text-muted-foreground">{selected.userName || selected.userEmail}</p><p className="mt-1 text-xs text-muted-foreground">{locationLabel || t.noAddress}</p></div>
                  <Button
                    variant="outline"
                    disabled={updateStatus.isPending}
                    onClick={() => updateStatus.mutate({ conversationId: selected.id, status: selected.status === "open" ? "closed" : "open" })}
                  >
                    {updateStatus.isPending && <LoaderCircle className="me-2 size-4 animate-spin" />}{selected.status === "open" ? t.closeThread : t.reopenThread}
                  </Button>
                </CardHeader>
              </Card>
            ) : null}
            <MessageList
              conversationId={selected?.id ?? null}
              ownerUserId={selected?.ownerUserId ?? null}
              userId={user.id}
              isAdmin
              isClosed={selected?.status === "closed"}
              direction={direction}
              t={t}
            />
          </section>
        </div>
      </div>
    </DashboardLayout>
  );
}
