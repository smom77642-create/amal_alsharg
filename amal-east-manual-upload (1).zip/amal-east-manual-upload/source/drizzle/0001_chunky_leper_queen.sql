ALTER TABLE `messages` ADD `attachmentKey` varchar(512);--> statement-breakpoint
ALTER TABLE `messages` ADD `attachmentMimeType` varchar(32);--> statement-breakpoint
ALTER TABLE `messages` ADD `attachmentName` varchar(180);--> statement-breakpoint
ALTER TABLE `messages` ADD `attachmentSize` int;