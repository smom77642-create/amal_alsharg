import {
  index,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

/** Core user table backing the session auth flow. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  /** Namespaced provider subject; Google IDs use `google:<sub>`. */
  openId: varchar("openId", { length: 280 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

/** User-entered coarse residence location; never inferred from Google. */
export const userProfiles = mysqlTable(
  "user_profiles",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
    country: varchar("country", { length: 120 }).notNull(),
    region: varchar("region", { length: 120 }).notNull(),
    city: varchar("city", { length: 120 }).notNull(),
    consentAt: timestamp("consentAt").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [uniqueIndex("user_profiles_userId_unique").on(table.userId)],
);

/** Each user may have multiple private support/contact threads. */
export const conversations = mysqlTable(
  "conversations",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerUserId: int("ownerUserId").notNull().references(() => users.id, { onDelete: "cascade" }),
    subject: varchar("subject", { length: 160 }).notNull(),
    status: mysqlEnum("status", ["open", "closed"]).default("open").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [index("conversations_owner_updated_idx").on(table.ownerUserId, table.updatedAt)],
);

/** Only the thread owner and an administrator may read or add messages. */
export const messages = mysqlTable(
  "messages",
  {
    id: int("id").autoincrement().primaryKey(),
    conversationId: int("conversationId").notNull().references(() => conversations.id, { onDelete: "cascade" }),
    senderUserId: int("senderUserId").notNull().references(() => users.id, { onDelete: "cascade" }),
    body: text("body").notNull(),
    attachmentKey: varchar("attachmentKey", { length: 512 }),
    attachmentMimeType: varchar("attachmentMimeType", { length: 32 }),
    attachmentName: varchar("attachmentName", { length: 180 }),
    attachmentSize: int("attachmentSize"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [index("messages_conversation_created_idx").on(table.conversationId, table.createdAt)],
);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type UserProfile = typeof userProfiles.$inferSelect;
export type Conversation = typeof conversations.$inferSelect;
export type Message = typeof messages.$inferSelect;
