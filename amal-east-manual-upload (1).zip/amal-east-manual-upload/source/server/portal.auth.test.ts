import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createContext(user: AuthenticatedUser): TrpcContext {
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => undefined } as unknown as TrpcContext["res"],
  };
}

function user(overrides: Partial<AuthenticatedUser> = {}): AuthenticatedUser {
  return {
    id: 2,
    openId: "google:opaque-subject",
    email: "member@example.org",
    name: "Member Name",
    loginMethod: "google",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
    ...overrides,
  };
}

describe("portal authorization", () => {
  it("blocks authenticated accounts that did not sign in through Google", async () => {
    const caller = appRouter.createCaller(createContext(user({ loginMethod: "email" })));
    await expect(caller.portal.profile()).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.portal.sendImageMessage({
      conversationId: 1,
      body: "",
      imageDataUrl: "data:image/jpeg;base64,/9j/AA==",
      fileName: "photo.jpg",
    })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("blocks a regular Google user from the administrator inbox", async () => {
    const caller = appRouter.createCaller(createContext(user()));
    await expect(caller.portal.adminInbox()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("returns only the client-safe auth profile fields", async () => {
    const caller = appRouter.createCaller(createContext(user()));
    const result = await caller.auth.me();
    expect(result).toMatchObject({ id: 2, email: "member@example.org", role: "user", loginMethod: "google" });
    expect(result).not.toHaveProperty("openId");
  });
});
