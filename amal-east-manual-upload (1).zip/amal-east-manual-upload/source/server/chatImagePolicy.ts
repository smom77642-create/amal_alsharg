import { canAccessConversation, isAuthorizedGoogleAdmin, isGoogleLoginMethod } from "./authPolicy";
import type { User } from "../drizzle/schema";

export const MAX_CHAT_IMAGE_BYTES = 5 * 1024 * 1024;

export type ChatImageMime = "image/jpeg" | "image/png" | "image/webp";

export function detectChatImageMime(bytes: Uint8Array): ChatImageMime | null {
  if (bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) {
    return "image/jpeg";
  }
  if (
    bytes.length >= 8 &&
    bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47 &&
    bytes[4] === 0x0d && bytes[5] === 0x0a && bytes[6] === 0x1a && bytes[7] === 0x0a
  ) {
    return "image/png";
  }
  if (
    bytes.length >= 12 &&
    String.fromCharCode(bytes[0]!, bytes[1]!, bytes[2]!, bytes[3]!) === "RIFF" &&
    String.fromCharCode(bytes[8]!, bytes[9]!, bytes[10]!, bytes[11]!) === "WEBP"
  ) {
    return "image/webp";
  }
  return null;
}

export function validateChatImage(bytes: Uint8Array, declaredMime?: string): ChatImageMime {
  if (!bytes.length) throw new Error("Image is empty.");
  if (bytes.length > MAX_CHAT_IMAGE_BYTES) throw new Error("Image exceeds the upload limit.");
  const detected = detectChatImageMime(bytes);
  if (!detected) throw new Error("Only valid JPEG, PNG, or WebP images are supported.");
  if (declaredMime && declaredMime !== detected) throw new Error("Image content does not match its declared type.");
  return detected;
}

export function parseChatImageDataUrl(value: string): { buffer: Buffer; mime: ChatImageMime } {
  const match = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/]+={0,2})$/.exec(value);
  if (!match || match[2]!.length % 4 !== 0) throw new Error("Select a valid JPEG, PNG, or WebP image.");
  const buffer = Buffer.from(match[2]!, "base64");
  const mime = validateChatImage(buffer, match[1]);
  if (buffer.toString("base64") !== match[2]) throw new Error("Image encoding is invalid.");
  return { buffer, mime };
}

export function safeChatImageName(name: string, mime: ChatImageMime): string {
  const pieces = name.split(/[\\/]/);
  const basename = pieces[pieces.length - 1] ?? "";
  const clean = basename
    .replace(/[\u0000-\u001f\u007f]/g, "")
    .replace(/\.[^.]*$/, "")
    .replace(/[<>"'`]/g, "")
    .replace(/[. ]+$/g, "")
    .trim()
    .slice(0, 120);
  const stem = clean && !/^\.+$/.test(clean) ? clean : "image";
  const extension = mime === "image/jpeg" ? "jpg" : mime.slice("image/".length);
  return `${stem}.${extension}`;
}

export function canReadPrivateChatImage(
  user: Pick<User, "id" | "email" | "role" | "loginMethod">,
  ownerUserId: number,
  allowedAdminEmails: readonly string[],
): boolean {
  if (!isGoogleLoginMethod(user.loginMethod)) return false;
  const isAuthorizedAdmin = isAuthorizedGoogleAdmin(user, allowedAdminEmails);
  return canAccessConversation({ userId: user.id, isAdmin: isAuthorizedAdmin }, ownerUserId);
}
