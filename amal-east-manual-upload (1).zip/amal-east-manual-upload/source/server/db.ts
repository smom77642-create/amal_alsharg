import { and, asc, count, desc, eq, gt, gte, isNotNull, like, lt, or } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  conversations,
  InsertUser,
  messages,
  userProfiles,
  users,
} from "../drizzle/schema";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the Drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

async function requireDb() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await requireDb();
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  type TextField = (typeof textFields)[number];

  const assignNullable = (field: TextField) => {
    const value = user[field];
    if (value === undefined) return;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  };
  textFields.forEach(assignNullable);

  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  } else {
    values.lastSignedIn = new Date();
    updateSet.lastSignedIn = values.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  }

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await requireDb();
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function saveUserProfile(
  userId: number,
  profile: { country: string; region: string; city: string },
  consentAt: Date,
) {
  const db = await requireDb();
  await db
    .insert(userProfiles)
    .values({ userId, ...profile, consentAt })
    .onDuplicateKeyUpdate({
      set: { ...profile, consentAt, updatedAt: new Date() },
    });
  return getUserProfile(userId);
}

export async function getUserProfile(userId: number) {
  const db = await requireDb();
  const result = await db.select().from(userProfiles).where(eq(userProfiles.userId, userId)).limit(1);
  return result[0] ?? null;
}

export async function createConversation(
  ownerUserId: number,
  subject: string,
  firstMessage: string,
) {
  const db = await requireDb();
  return db.transaction(async tx => {
    const [created] = await tx
      .insert(conversations)
      .values({ ownerUserId, subject })
      .$returningId();
    if (!created) throw new Error("Conversation was not created");
    await tx.insert(messages).values({
      conversationId: created.id,
      senderUserId: ownerUserId,
      body: firstMessage,
    });
    return created.id;
  });
}

export async function getConversation(conversationId: number) {
  const db = await requireDb();
  const result = await db.select().from(conversations).where(eq(conversations.id, conversationId)).limit(1);
  return result[0] ?? null;
}

export async function listUserConversations(ownerUserId: number) {
  const db = await requireDb();
  return db
    .select()
    .from(conversations)
    .where(eq(conversations.ownerUserId, ownerUserId))
    .orderBy(desc(conversations.updatedAt))
    .limit(50);
}

export async function listAdminInbox() {
  const db = await requireDb();
  return db
    .select({
      id: conversations.id,
      ownerUserId: conversations.ownerUserId,
      subject: conversations.subject,
      status: conversations.status,
      createdAt: conversations.createdAt,
      updatedAt: conversations.updatedAt,
      userName: users.name,
      userEmail: users.email,
      city: userProfiles.city,
      region: userProfiles.region,
      country: userProfiles.country,
    })
    .from(conversations)
    .innerJoin(users, eq(conversations.ownerUserId, users.id))
    .leftJoin(userProfiles, eq(userProfiles.userId, users.id))
    .orderBy(desc(conversations.updatedAt))
    .limit(100);
}

export async function listMessages(conversationId: number) {
  const db = await requireDb();
  return db
    .select({
      id: messages.id,
      conversationId: messages.conversationId,
      senderUserId: messages.senderUserId,
      body: messages.body,
      attachmentMimeType: messages.attachmentMimeType,
      attachmentName: messages.attachmentName,
      attachmentSize: messages.attachmentSize,
      createdAt: messages.createdAt,
    })
    .from(messages)
    .where(eq(messages.conversationId, conversationId))
    .orderBy(asc(messages.createdAt), asc(messages.id))
    .limit(500);
}

export async function getMessageAttachment(messageId: number) {
  const db = await requireDb();
  const [row] = await db
    .select({
      id: messages.id,
      conversationId: messages.conversationId,
      attachmentKey: messages.attachmentKey,
      attachmentMimeType: messages.attachmentMimeType,
      attachmentName: messages.attachmentName,
      attachmentSize: messages.attachmentSize,
    })
    .from(messages)
    .where(eq(messages.id, messageId))
    .limit(1);
  return row ?? null;
}

export async function addMessage(
  conversationId: number,
  senderUserId: number,
  body: string,
  attachment?: { key: string; mimeType: string; name: string; size: number },
) {
  const db = await requireDb();
  await db.transaction(async tx => {
    await tx.insert(messages).values({
      conversationId,
      senderUserId,
      body,
      ...(attachment ? {
        attachmentKey: attachment.key,
        attachmentMimeType: attachment.mimeType,
        attachmentName: attachment.name,
        attachmentSize: attachment.size,
      } : {}),
    });
    await tx
      .update(conversations)
      .set({ updatedAt: new Date() })
      .where(eq(conversations.id, conversationId));
  });
}

export async function countRecentMessages(senderUserId: number, since: Date) {
  const db = await requireDb();
  const [row] = await db
    .select({ total: count() })
    .from(messages)
    .where(and(eq(messages.senderUserId, senderUserId), gte(messages.createdAt, since)))
    .limit(1);
  return Number(row?.total ?? 0);
}

export async function countRecentImageMessages(senderUserId: number, since: Date) {
  const db = await requireDb();
  const [row] = await db
    .select({ total: count() })
    .from(messages)
    .where(and(
      eq(messages.senderUserId, senderUserId),
      isNotNull(messages.attachmentKey),
      gte(messages.createdAt, since),
    ))
    .limit(1);
  return Number(row?.total ?? 0);
}

export async function setConversationStatus(conversationId: number, status: "open" | "closed") {
  const db = await requireDb();
  await db.update(conversations).set({ status, updatedAt: new Date() }).where(eq(conversations.id, conversationId));
}

export async function listAdminUsers(page: number, pageSize: number, search: string) {
  const db = await requireDb();
  const escapedSearch = search.trim().replace(/[\\%_]/g, "\\$&");
  const filter = escapedSearch
    ? or(like(users.name, `%${escapedSearch}%`), like(users.email, `%${escapedSearch}%`))
    : undefined;
  const [countRow] = await db.select({ total: count() }).from(users).where(filter).limit(1);
  const items = await db
    .select({
      id: users.id,
      name: users.name,
      email: users.email,
      role: users.role,
      loginMethod: users.loginMethod,
      createdAt: users.createdAt,
      lastSignedIn: users.lastSignedIn,
      city: userProfiles.city,
      region: userProfiles.region,
      country: userProfiles.country,
      consentAt: userProfiles.consentAt,
    })
    .from(users)
    .leftJoin(userProfiles, eq(userProfiles.userId, users.id))
    .where(filter)
    .orderBy(desc(users.createdAt), desc(users.id))
    .limit(pageSize)
    .offset(page * pageSize);
  return { items, total: Number(countRow?.total ?? 0), page, pageSize };
}

export async function listAdminExportPage(
  afterMessageId: number | null,
  pageSize: number,
  fromDate: Date | null,
  toDateExclusive: Date | null,
) {
  const db = await requireDb();
  const query = db
    .select({
      messageId: messages.id,
      conversationId: conversations.id,
      conversationSubject: conversations.subject,
      conversationStatus: conversations.status,
      conversationCreatedAt: conversations.createdAt,
      userName: users.name,
      userEmail: users.email,
      city: userProfiles.city,
      region: userProfiles.region,
      country: userProfiles.country,
      ownerUserId: conversations.ownerUserId,
      senderUserId: messages.senderUserId,
      messageBody: messages.body,
      attachmentName: messages.attachmentName,
      attachmentMimeType: messages.attachmentMimeType,
      messageCreatedAt: messages.createdAt,
    })
    .from(messages)
    .innerJoin(conversations, eq(messages.conversationId, conversations.id))
    .innerJoin(users, eq(conversations.ownerUserId, users.id))
    .leftJoin(userProfiles, eq(userProfiles.userId, users.id));
  const filters = [];
  if (afterMessageId !== null) filters.push(gt(messages.id, afterMessageId));
  if (fromDate) filters.push(gte(messages.createdAt, fromDate));
  if (toDateExclusive) filters.push(lt(messages.createdAt, toDateExclusive));
  const rows = await query.where(and(...filters)).orderBy(asc(messages.id)).limit(pageSize + 1);
  const hasMore = rows.length > pageSize;
  const page = rows.slice(0, pageSize);
  const last = page.at(-1);
  return {
    items: page.map(row => ({
      messageId: row.messageId,
      conversationId: row.conversationId,
      conversationSubject: row.conversationSubject,
      conversationStatus: row.conversationStatus,
      conversationCreatedAt: row.conversationCreatedAt,
      userName: row.userName,
      userEmail: row.userEmail,
      city: row.city,
      region: row.region,
      country: row.country,
      senderType: row.senderUserId === row.ownerUserId ? ("user" as const) : ("team" as const),
      messageBody: row.messageBody,
      attachmentName: row.attachmentName,
      attachmentMimeType: row.attachmentMimeType,
      messageCreatedAt: row.messageCreatedAt,
    })),
    hasMore,
    nextCursor: last?.messageId ?? afterMessageId,
  };
}
