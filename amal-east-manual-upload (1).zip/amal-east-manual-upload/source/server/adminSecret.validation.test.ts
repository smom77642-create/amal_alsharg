import { describe, expect, it } from "vitest";
import { isAdminGoogleEmail } from "./authPolicy";
import { appRouter } from "./routers";
import { ENV } from "./_core/env";
import type { TrpcContext } from "./_core/context";

function createAdminContext(email: string): TrpcContext {
  return {
    user: {
      id: 7001,
      openId: "google:configured-admin-check",
      email,
      name: "Configured admin check",
      loginMethod: "google",
      role: "admin",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => undefined } as unknown as TrpcContext["res"],
  };
}

describe("configured administrator email", () => {
  it("is present and matches the server allowlist without exposing its value", () => {
    expect(ENV.adminGoogleEmails.length).toBeGreaterThan(0);
    expect(ENV.adminGoogleEmails.every(email => email === email.trim().toLowerCase())).toBe(true);
    expect(isAdminGoogleEmail(ENV.adminGoogleEmails[0], ENV.adminGoogleEmails)).toBe(true);
    expect(isAdminGoogleEmail("not-the-configured-admin@example.invalid", ENV.adminGoogleEmails)).toBe(false);
  });

  it("passes the lightweight admin access API using the configured Google account", async () => {
    const caller = appRouter.createCaller(createAdminContext(ENV.adminGoogleEmails[0]!));
    await expect(caller.portal.adminAccessCheck()).resolves.toEqual({ allowed: true });
    await expect(caller.portal.adminExportPage({ fromDate: "2026-02-30" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    await expect(caller.portal.adminExportPage({ fromDate: "2026-10-09", toDate: "2026-10-08" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("denies another Google email even if its stored role says admin", async () => {
    const caller = appRouter.createCaller(createAdminContext("someone-else@example.invalid"));
    await expect(caller.portal.adminAccessCheck()).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.portal.adminUsers({})).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.portal.adminExportPage({})).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
