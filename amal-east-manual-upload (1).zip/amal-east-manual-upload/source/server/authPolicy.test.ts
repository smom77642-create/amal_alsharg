import { describe, expect, it } from "vitest";
import {
  canAccessConversation,
  isAdminGoogleEmail,
  isGoogleLoginMethod,
  normalizeAdminEmails,
  isAuthorizedGoogleAdmin,
  namespaceGoogleSubject,
  safeOAuthReturnPath,
} from "./authPolicy";

describe("authentication and conversation policies", () => {
  it("accepts only a Google sign-in method", () => {
    expect(isGoogleLoginMethod("google")).toBe(true);
    expect(isGoogleLoginMethod("REGISTERED_PLATFORM_GOOGLE")).toBe(true);
    expect(isGoogleLoginMethod("email")).toBe(false);
    expect(isGoogleLoginMethod(undefined)).toBe(false);
  });

  it("namespaces and bounds Google subject IDs", () => {
    expect(namespaceGoogleSubject("subject-42")).toBe("google:subject-42");
    expect(() => namespaceGoogleSubject(" ")).toThrow("Invalid Google subject");
    expect(() => namespaceGoogleSubject("x".repeat(256))).toThrow("Invalid Google subject");
  });

  it("grants administrator role only to the configured email", () => {
    expect(isAdminGoogleEmail("Admin@Example.org", "admin@example.org")).toBe(true);
    expect(isAdminGoogleEmail("admin+other@example.org", "admin@example.org")).toBe(false);
    expect(isAdminGoogleEmail("admin@example.org", "")).toBe(false);
    const admins = normalizeAdminEmails([" first@example.org, SECOND@example.org ", "first@example.org"]);
    expect(admins).toEqual(["first@example.org", "second@example.org", "first@example.org"]);
    expect(isAdminGoogleEmail("Second@Example.org", admins)).toBe(true);
    expect(isAdminGoogleEmail("third@example.org", admins)).toBe(false);
    expect(isAuthorizedGoogleAdmin({ email: "second@example.org", role: "admin", loginMethod: "google" }, admins)).toBe(true);
    expect(isAuthorizedGoogleAdmin({ email: "second@example.org", role: "admin", loginMethod: "google" }, ["first@example.org"])).toBe(false);
    expect(isAuthorizedGoogleAdmin({ email: "second@example.org", role: "admin", loginMethod: "email" }, admins)).toBe(false);
  });

  it("permits only a safe same-site return path", () => {
    expect(safeOAuthReturnPath("/portal.html?tab=messages")).toBe("/portal.html?tab=messages");
    expect(safeOAuthReturnPath("https://attacker.invalid/steal")).toBe("/portal.html");
    expect(safeOAuthReturnPath("//attacker.invalid")).toBe("/portal.html");
    expect(safeOAuthReturnPath("/\\attacker.invalid")).toBe("/portal.html");
  });

  it("limits private conversation access to its owner and administrators", () => {
    expect(canAccessConversation({ userId: 8, isAdmin: false }, 8)).toBe(true);
    expect(canAccessConversation({ userId: 9, isAdmin: false }, 8)).toBe(false);
    expect(canAccessConversation({ userId: 9, isAdmin: true }, 8)).toBe(true);
  });
});
