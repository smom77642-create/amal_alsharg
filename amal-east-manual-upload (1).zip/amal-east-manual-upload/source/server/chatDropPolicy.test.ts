import { describe, expect, it } from "vitest";
import { firstDroppedImage, MAX_CHAT_IMAGES_PER_BATCH, supportedDroppedImages } from "../client/src/lib/chatDropPolicy";

describe("chat image drag-and-drop selection", () => {
  it("skips non-image files and returns the first dropped image", () => {
    const image = { name: "care-photo.png", type: "image/png" };
    expect(firstDroppedImage([
      { name: "notes.txt", type: "text/plain" },
      { name: "vector.svg", type: "image/svg+xml" },
      image,
      { name: "later.jpg", type: "image/jpeg" },
    ])).toBe(image);
  });

  it("returns null when no image is dropped", () => {
    expect(firstDroppedImage([
      { name: "notes.txt", type: "text/plain" },
      { name: "report.pdf", type: "application/pdf" },
    ])).toBeNull();
  });

  it("returns null when only unsupported image types are dropped", () => {
    expect(firstDroppedImage([{ name: "animation.gif", type: "image/gif" }])).toBeNull();
  });

  it("collects all supported images from a mixed drop in their original order", () => {
    const files = [
      { name: "first.jpg", type: "image/jpeg" },
      { name: "notes.txt", type: "text/plain" },
      { name: "second.webp", type: "image/webp" },
      { name: "animation.gif", type: "image/gif" },
      { name: "third.png", type: "image/png" },
    ];
    expect(supportedDroppedImages(files).map(file => file.name)).toEqual([
      "first.jpg", "second.webp", "third.png",
    ]);
  });

  it("matches the batch limit to the existing server-side rolling image quota", () => {
    expect(MAX_CHAT_IMAGES_PER_BATCH).toBe(8);
  });
});
