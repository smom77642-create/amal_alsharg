import type { Express } from "express";
import * as db from "../db";
import { canReadPrivateChatImage, validateChatImage } from "../chatImagePolicy";
import { isGoogleLoginMethod } from "../authPolicy";
import { ENV } from "./env";
import { sdk } from "./sdk";
import { storageGetSignedUrl } from "../storage";

async function readBounded(response: Response, maxBytes: number): Promise<Buffer> {
  if (response.body === null) throw new Error("Image storage returned no body.");
  const announcedLength = Number(response.headers.get("content-length") ?? 0);
  if (announcedLength > maxBytes) throw new Error("Stored image exceeds the allowed size.");
  const reader = response.body.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.byteLength;
    if (total > maxBytes) {
      await reader.cancel();
      throw new Error("Stored image exceeds the allowed size.");
    }
    chunks.push(value);
  }
  return Buffer.concat(chunks.map(chunk => Buffer.from(chunk)));
}

export function registerChatImageRoutes(app: Express) {
  app.get("/api/chat/images/:messageId", async (req, res) => {
    const messageId = Number(req.params.messageId);
    if (!Number.isSafeInteger(messageId) || messageId <= 0) {
      res.status(400).send("Invalid image request.");
      return;
    }

    try {
      let user;
      try {
        user = await sdk.authenticateRequest(req);
      } catch {
        res.status(401).send("Sign in with Google to view this image.");
        return;
      }
      if (!isGoogleLoginMethod(user.loginMethod)) {
        res.status(401).send("Sign in with Google to view this image.");
        return;
      }
      const attachment = await db.getMessageAttachment(messageId);
      if (!attachment?.attachmentKey || !attachment.attachmentMimeType) {
        res.status(404).send("Image not found.");
        return;
      }
      const conversation = await db.getConversation(attachment.conversationId);
      if (!conversation || !canReadPrivateChatImage(user, conversation.ownerUserId, ENV.adminGoogleEmails)) {
        res.status(404).send("Image not found.");
        return;
      }

      const signedUrl = await storageGetSignedUrl(attachment.attachmentKey);
      const stored = await fetch(signedUrl, { signal: AbortSignal.timeout(15_000) });
      if (!stored.ok) {
        res.status(502).send("Image storage is temporarily unavailable.");
        return;
      }
      const bytes = await readBounded(stored, 5 * 1024 * 1024);
      const mime = validateChatImage(bytes, attachment.attachmentMimeType);
      res
        .status(200)
        .set("Content-Type", mime)
        .set("Content-Length", String(bytes.byteLength))
        .set("Cache-Control", "private, no-store")
        .set("X-Content-Type-Options", "nosniff")
        .set("X-Frame-Options", "DENY")
        .set("Referrer-Policy", "no-referrer")
        .set("Content-Security-Policy", "default-src 'none'; sandbox")
        .send(bytes);
    } catch (error) {
      console.error("[ChatImage] Could not serve private attachment:", error instanceof Error ? error.message : "unknown error");
      if (!res.headersSent) res.status(502).send("Image is temporarily unavailable.");
    }
  });
}
