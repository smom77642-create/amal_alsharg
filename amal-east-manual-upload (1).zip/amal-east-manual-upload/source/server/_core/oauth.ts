import { COOKIE_NAME, OAUTH_STATE_COOKIE, ONE_YEAR_MS, decodeOAuthState } from "@shared/const";
import { parse as parseCookieHeader } from "cookie";
import type { Express, Request, Response } from "express";
import { isAdminGoogleEmail, isGoogleLoginMethod, namespaceGoogleSubject, safeOAuthReturnPath } from "../authPolicy";
import * as db from "../db";
import { ENV } from "./env";
import { getSessionCookieOptions } from "./cookies";
import { sdk } from "./sdk";

const SESSION_MS = Math.min(ONE_YEAR_MS, 30 * 24 * 60 * 60 * 1000);

function getQueryParam(req: Request, key: string): string | undefined {
  const value = req.query[key];
  return typeof value === "string" ? value : undefined;
}

export function registerOAuthRoutes(app: Express) {
  app.get("/api/oauth/callback", async (req: Request, res: Response) => {
    const code = getQueryParam(req, "code");
    const state = getQueryParam(req, "state");
    if (!code || !state) {
      res.status(400).type("text/plain").send("Sign-in could not be completed. Please return to the site and try again.");
      return;
    }

    const statePayload = decodeOAuthState(state);
    const expectedNonce = parseCookieHeader(req.headers.cookie ?? "")[OAUTH_STATE_COOKIE];
    if (!statePayload.nonce || statePayload.nonce !== expectedNonce) {
      res.status(403).type("text/plain").send("Sign-in could not be verified. Please return to the site and try again.");
      return;
    }
    res.clearCookie(OAUTH_STATE_COOKIE, { path: "/", secure: true, sameSite: "none" });

    try {
      const tokenResponse = await sdk.exchangeCodeForToken(code, state);
      const userInfo = await sdk.getUserInfo(tokenResponse.accessToken);
      const returnTo = safeOAuthReturnPath(statePayload.returnTo);
      const loginMethod = userInfo.loginMethod ?? userInfo.platform;

      // The existing server-side provider metadata is authoritative. Other login
      // methods do not get an application session, even if they share an email.
      if (!isGoogleLoginMethod(loginMethod) || !userInfo.email?.trim()) {
        res.redirect(302, "/contact.html?auth=google-required");
        return;
      }

      const email = userInfo.email.trim().toLowerCase();
      const displayName = userInfo.name?.trim().slice(0, 240) || email;
      const openId = namespaceGoogleSubject(userInfo.openId);
      await db.upsertUser({
        openId,
        name: displayName,
        email,
        loginMethod: "google",
        role: isAdminGoogleEmail(email, ENV.adminGoogleEmails) ? "admin" : "user",
        lastSignedIn: new Date(),
      });

      const sessionToken = await sdk.createSessionToken(openId, {
        name: displayName,
        expiresInMs: SESSION_MS,
      });
      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: SESSION_MS });
      res.redirect(302, returnTo);
    } catch {
      // Never log authorization codes, access tokens, or personal identity data.
      console.error("[OAuth] Sign-in callback failed");
      res.status(401).type("text/plain").send("Sign-in was not completed. Please return to the site and try again.");
    }
  });
}
