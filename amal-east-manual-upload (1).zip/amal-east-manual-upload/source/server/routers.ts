import { TRPCError } from "@trpc/server";
import { randomUUID } from "node:crypto";
import { z } from "zod";
import { canAccessConversation, isAuthorizedGoogleAdmin } from "./authPolicy";
import { parseChatImageDataUrl, safeChatImageName } from "./chatImagePolicy";
import * as db from "./db";
import { ENV } from "./_core/env";
import { storagePut } from "./storage";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, googleProcedure, publicProcedure, router } from "./_core/trpc";

const idInput = z.object({ conversationId: z.number().int().positive() });
const locationInput = z.object({
  country: z.string().trim().min(1).max(120),
  region: z.string().trim().min(1).max(120),
  city: z.string().trim().min(1).max(120),
  consent: z.literal(true),
});
const messageText = z.string().trim().min(1).max(5000);

function parseExportDate(value: string | null): Date | null {
  if (!value) return null;
  const date = new Date(`${value}T00:00:00.000Z`);
  if (!Number.isFinite(date.getTime()) || date.toISOString().slice(0, 10) !== value) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "Invalid export date." });
  }
  return date;
}

async function requireConversationAccess(conversationId: number, userId: number, isAdmin: boolean) {
  const conversation = await db.getConversation(conversationId);
  if (!conversation || !canAccessConversation({ userId, isAdmin }, conversation.ownerUserId)) {
    throw new TRPCError({ code: "NOT_FOUND", message: "Conversation not found." });
  }
  return conversation;
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(({ ctx }) => {
      const user = ctx.user;
      if (!user) return null;
      return {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        loginMethod: user.loginMethod,
      };
    }),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  portal: router({
    profile: googleProcedure.query(({ ctx }) => db.getUserProfile(ctx.user.id)),
    saveProfile: googleProcedure.input(locationInput).mutation(({ ctx, input }) =>
      db.saveUserProfile(
        ctx.user.id,
        { country: input.country, region: input.region, city: input.city },
        new Date(),
      ),
    ),
    myConversations: googleProcedure.query(({ ctx }) => db.listUserConversations(ctx.user.id)),
    startConversation: googleProcedure
      .input(z.object({ subject: z.string().trim().min(1).max(160), message: messageText }))
      .mutation(async ({ ctx, input }) => {
        if (!(await db.getUserProfile(ctx.user.id))) {
          throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Complete your profile first." });
        }
        const recentCount = await db.countRecentMessages(ctx.user.id, new Date(Date.now() - 10 * 60 * 1000));
        if (recentCount >= 5) {
          throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Please wait before starting another request." });
        }
        return db.createConversation(ctx.user.id, input.subject, input.message);
      }),
    adminAccessCheck: adminProcedure.query(() => ({ allowed: true as const })),
    adminInbox: adminProcedure.query(() => db.listAdminInbox()),
    adminUsers: adminProcedure
      .input(z.object({
        page: z.number().int().min(0).max(100000).default(0),
        pageSize: z.number().int().min(1).max(100).default(25),
        query: z.string().trim().max(120).default(""),
      }))
      .query(({ input }) => db.listAdminUsers(input.page, input.pageSize, input.query)),
    adminExportPage: adminProcedure
      .input(z.object({
        afterMessageId: z.number().int().positive().nullable().default(null),
        fromDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).nullable().default(null),
        toDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).nullable().default(null),
      }))
      .query(({ input }) => {
        const fromDate = parseExportDate(input.fromDate);
        const toDate = parseExportDate(input.toDate);
        if (fromDate && toDate && fromDate > toDate) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Export start date must not be after the end date." });
        }
        const toDateExclusive = toDate ? new Date(toDate.getTime() + 24 * 60 * 60 * 1000) : null;
        return db.listAdminExportPage(input.afterMessageId, 250, fromDate, toDateExclusive);
      }),
    messages: googleProcedure.input(idInput).query(async ({ ctx, input }) => {
      const isAdmin = isAuthorizedGoogleAdmin(ctx.user, ENV.adminGoogleEmails);
      await requireConversationAccess(input.conversationId, ctx.user.id, isAdmin);
      const messages = await db.listMessages(input.conversationId);
      return messages.map(message => ({
        ...message,
        attachmentUrl: message.attachmentMimeType ? `/api/chat/images/${message.id}` : null,
      }));
    }),
    sendMessage: googleProcedure
      .input(idInput.extend({ body: messageText }))
      .mutation(async ({ ctx, input }) => {
        const isAdmin = isAuthorizedGoogleAdmin(ctx.user, ENV.adminGoogleEmails);
        const conversation = await requireConversationAccess(input.conversationId, ctx.user.id, isAdmin);
        if (conversation.status === "closed" && !isAdmin) {
          throw new TRPCError({ code: "PRECONDITION_FAILED", message: "This conversation is closed." });
        }
        const recentCount = await db.countRecentMessages(ctx.user.id, new Date(Date.now() - 10 * 60 * 1000));
        if (recentCount >= 30) {
          throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Please wait before sending another message." });
        }
        await db.addMessage(input.conversationId, ctx.user.id, input.body);
        return { success: true } as const;
      }),
    sendImageMessage: googleProcedure
      .input(z.object({
        conversationId: z.number().int().positive(),
        body: z.string().trim().max(5000).default(""),
        imageDataUrl: z.string().max(7_100_000),
        fileName: z.string().max(255).default("image"),
      }))
      .mutation(async ({ ctx, input }) => {
        const isAdmin = isAuthorizedGoogleAdmin(ctx.user, ENV.adminGoogleEmails);
        const conversation = await requireConversationAccess(input.conversationId, ctx.user.id, isAdmin);
        if (conversation.status === "closed" && !isAdmin) {
          throw new TRPCError({ code: "PRECONDITION_FAILED", message: "This conversation is closed." });
        }
        const recentCount = await db.countRecentMessages(ctx.user.id, new Date(Date.now() - 10 * 60 * 1000));
        if (recentCount >= 30) {
          throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Please wait before sending another message." });
        }
        const recentImageCount = await db.countRecentImageMessages(ctx.user.id, new Date(Date.now() - 10 * 60 * 1000));
        if (recentImageCount >= 8) {
          throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Please wait before uploading another image." });
        }
        let parsed: ReturnType<typeof parseChatImageDataUrl>;
        try {
          parsed = parseChatImageDataUrl(input.imageDataUrl);
        } catch (error) {
          throw new TRPCError({ code: "BAD_REQUEST", message: error instanceof Error ? error.message : "Invalid image." });
        }
        const name = safeChatImageName(input.fileName, parsed.mime);
        try {
          const stored = await storagePut(
            `chat-images/${input.conversationId}/${randomUUID()}-${name}`,
            parsed.buffer,
            parsed.mime,
          );
          await db.addMessage(input.conversationId, ctx.user.id, input.body, {
            key: stored.key,
            mimeType: parsed.mime,
            name,
            size: parsed.buffer.length,
          });
          return { success: true } as const;
        } catch (error) {
          console.error("[ChatImage] Upload failed:", error instanceof Error ? error.message : "unknown error");
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Image could not be sent." });
        }
      }),
    setStatus: adminProcedure
      .input(idInput.extend({ status: z.enum(["open", "closed"]) }))
      .mutation(async ({ input }) => {
        await requireConversationAccess(input.conversationId, 0, true);
        await db.setConversationStatus(input.conversationId, input.status);
        return { success: true } as const;
      }),
  }),
});

export type AppRouter = typeof appRouter;
