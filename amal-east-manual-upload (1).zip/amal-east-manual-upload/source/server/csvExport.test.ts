import { describe, expect, it } from "vitest";
import { conversationCsvHeader, conversationCsvRows, type ConversationExportRow } from "../client/src/lib/conversationCsv";

const row: ConversationExportRow = {
  userName: "مستخدم, جديد",
  userEmail: "person@example.org",
  city: "River \"Town\"\nDistrict",
  region: "Region",
  country: "Sudan",
  conversationId: 17,
  conversationSubject: "Follow-up",
  conversationStatus: "open",
  conversationCreatedAt: new Date("2026-10-08T10:00:00.000Z"),
  senderType: "user",
  messageBody: "=HYPERLINK(\"https://example.invalid\")",
  attachmentName: "photo.webp",
  attachmentMimeType: "image/webp",
  messageCreatedAt: new Date("2026-10-08T10:01:00.000Z"),
};

describe("private conversation CSV", () => {
  it("writes a stable quoted header and protects spreadsheet formula cells", () => {
    expect(conversationCsvHeader()).toContain('"User name","User email"');
    const csv = conversationCsvRows([row]);
    expect(csv).toContain('"مستخدم, جديد"');
    expect(csv).toContain('"River ""Town""\nDistrict"');
    expect(csv).toContain("\"'=HYPERLINK(\"\"https://example.invalid\"\")\"");
    expect(csv).toContain('"2026-10-08T10:00:00.000Z"');
    expect(csv).toContain('"photo.webp"');
  });

  it("returns no spurious rows for an empty conversation list", () => {
    expect(conversationCsvRows([])).toBe("");
  });
});
