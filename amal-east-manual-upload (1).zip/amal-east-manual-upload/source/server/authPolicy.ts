export function safeOAuthReturnPath(value: unknown): string {
  if (typeof value !== "string") return "/portal.html";
  const path = value.trim();
  if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\") || /[\r\n]/.test(path)) {
    return "/portal.html";
  }
  try {
    const parsed = new URL(path, "https://amal-east.invalid");
    return parsed.origin === "https://amal-east.invalid"
      ? `${parsed.pathname}${parsed.search}${parsed.hash}`
      : "/portal.html";
  } catch {
    return "/portal.html";
  }
}

export function isGoogleLoginMethod(method: string | null | undefined): boolean {
  const normalized = (method ?? "").trim().toLowerCase();
  return normalized === "google" || normalized === "registered_platform_google";
}

export function namespaceGoogleSubject(subject: string): string {
  const normalized = subject.trim();
  if (!normalized || normalized.length > 255) throw new Error("Invalid Google subject");
  return `google:${normalized}`;
}

export function normalizeAdminEmails(values: readonly string[]): string[] {
  return values.flatMap(value => value.split(",")).map(value => value.trim().toLowerCase()).filter(Boolean);
}

export function isAdminGoogleEmail(
  email: string | null | undefined,
  allowedEmails: string | readonly string[],
): boolean {
  const normalized = email?.trim().toLowerCase() ?? "";
  const candidates = Array.isArray(allowedEmails) ? allowedEmails : [allowedEmails];
  return Boolean(normalized && candidates.some(value => value.trim().toLowerCase() === normalized));
}

export function isAuthorizedGoogleAdmin(
  user: { email?: string | null; role?: string | null; loginMethod?: string | null },
  allowedEmails: readonly string[],
): boolean {
  return user.role === "admin" && isGoogleLoginMethod(user.loginMethod) &&
    isAdminGoogleEmail(user.email, allowedEmails);
}

export function canAccessConversation(actor: { userId: number; isAdmin: boolean }, ownerUserId: number): boolean {
  return actor.isAdmin || actor.userId === ownerUserId;
}
