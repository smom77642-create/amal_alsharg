import { describe, expect, it } from "vitest";
import { MAX_CHAT_IMAGE_BYTES, canReadPrivateChatImage, detectChatImageMime, parseChatImageDataUrl, safeChatImageName, validateChatImage } from "./chatImagePolicy";
import type { User } from "../drizzle/schema";

const jpeg = Uint8Array.from([0xff, 0xd8, 0xff, 0x00]);
const png = Uint8Array.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
const webp = Uint8Array.from([0x52, 0x49, 0x46, 0x46, 0, 0, 0, 0, 0x57, 0x45, 0x42, 0x50]);

function makeUser(overrides: Partial<User> = {}): User {
  const now = new Date();
  return {
    id: 1, openId: "google:subject", name: "Member", email: "member@example.org",
    loginMethod: "google", role: "user", createdAt: now, updatedAt: now, lastSignedIn: now,
    ...overrides,
  };
}

describe("private chat image policy", () => {
  it("recognizes only the supported image signatures", () => {
    expect(detectChatImageMime(jpeg)).toBe("image/jpeg");
    expect(detectChatImageMime(png)).toBe("image/png");
    expect(detectChatImageMime(webp)).toBe("image/webp");
    expect(detectChatImageMime(new TextEncoder().encode("<svg onload=alert(1)>"))).toBeNull();
  });

  it("validates the declared type against the signature and enforces the size cap", () => {
    expect(validateChatImage(jpeg, "image/jpeg")).toBe("image/jpeg");
    expect(() => validateChatImage(jpeg, "image/png")).toThrow(/does not match/);
    expect(() => validateChatImage(new Uint8Array())).toThrow(/empty/);
    expect(() => validateChatImage(new Uint8Array(MAX_CHAT_IMAGE_BYTES + 1))).toThrow(/limit/);
  });

  it("parses only valid, supported image data URLs", () => {
    const dataUrl = `data:image/jpeg;base64,${Buffer.from(jpeg).toString("base64")}`;
    expect(parseChatImageDataUrl(dataUrl).mime).toBe("image/jpeg");
    expect(() => parseChatImageDataUrl("data:image/svg+xml;base64,PHN2Zz4=")).toThrow(/valid JPEG/);
    expect(() => parseChatImageDataUrl("data:image/jpeg;base64,%%%%")).toThrow(/valid JPEG/);
  });

  it("sanitizes uploaded filenames and forces the verified extension", () => {
    expect(safeChatImageName("../../portrait.png", "image/jpeg")).toBe("portrait.jpg");
    expect(safeChatImageName("../\u0000<script>.webp", "image/webp")).toBe("script.webp");
    expect(safeChatImageName("...", "image/png")).toBe("image.png");
  });

  it("allows only the Google-authenticated thread owner or configured Google admin", () => {
    expect(canReadPrivateChatImage(makeUser({ id: 4 }), 4, ["admin@example.org"])).toBe(true);
    expect(canReadPrivateChatImage(makeUser({ id: 4, loginMethod: "registered_platform_google" }), 4, ["admin@example.org"])).toBe(true);
    expect(canReadPrivateChatImage(makeUser({ id: 5 }), 4, ["admin@example.org"])).toBe(false);
    expect(canReadPrivateChatImage(makeUser({ id: 5, email: "ADMIN@example.org", role: "admin" }), 4, ["admin@example.org"])).toBe(true);
    expect(canReadPrivateChatImage(makeUser({ id: 5, email: "spoof@example.org", role: "admin" }), 4, ["admin@example.org"])).toBe(false);
    expect(canReadPrivateChatImage(makeUser({ id: 4, loginMethod: "email" }), 4, ["admin@example.org"])).toBe(false);
  });
});
